param([string]$Python = "C:\Users\And\AppData\Local\1688XianyuAssistant\exe-builder\.venv\Scripts\python.exe")
$ErrorActionPreference = "Stop"
$Project = (Resolve-Path $PSScriptRoot).Path
$Build = Join-Path $Project "build-artifacts"
$Release = Join-Path $Project "release"

# Codex may prepend document/PDF helper runtimes to PATH.  PyInstaller scans
# PATH for imported DLL names; Qt 6 imports Windows' ICU shim (icuuc.dll), and
# an unrelated Poppler ICU found there was previously copied into the app.
# That incompatible DLL made QtWidgets fail before the first window appeared.
# Keep build-tool discovery deterministic by excluding those helper runtimes.
$env:Path = (($env:Path -split ";") | Where-Object {
  $_ -and $_ -notlike "*\codex-runtimes\*"
}) -join ";"

function Reset-ProjectDirectory([string]$Path) {
    $full = [System.IO.Path]::GetFullPath($Path)
    if (-not $full.StartsWith($Project + [System.IO.Path]::DirectorySeparatorChar)) { throw "Refusing unsafe path: $full" }
    if (Test-Path -LiteralPath $full) { Remove-Item -LiteralPath $full -Recurse -Force }
    New-Item -ItemType Directory -Path $full | Out-Null
}

Reset-ProjectDirectory $Build
Reset-ProjectDirectory $Release
New-Item -ItemType Directory -Path (Join-Path $Project "installer\payload") -Force | Out-Null

$env:XIANYU_BUILD_PROJECT = $Project
& $Python -m PyInstaller --noconfirm --clean `
  --distpath (Join-Path $Build "app-dist") `
  --workpath (Join-Path $Build "app-work") `
  (Join-Path $Project "installer\1688XianyuAssistant.spec")
if ($LASTEXITCODE -ne 0) { throw "Main application build failed" }

$CollectToc = Join-Path $Build "app-work\1688XianyuAssistant\COLLECT-00.toc"
$TocText = Get-Content -LiteralPath $CollectToc -Raw
if ($TocText -match "codex-runtimes") {
  throw "Main application accidentally captured a Codex helper-runtime DLL"
}

$Payload = Join-Path $Project "installer\payload\app_payload.zip"
if (Test-Path -LiteralPath $Payload) { Remove-Item -LiteralPath $Payload -Force }
Compress-Archive -Path (Join-Path $Build "app-dist\1688XianyuAssistant\*") -DestinationPath $Payload -CompressionLevel Optimal

& $Python -m PyInstaller --noconfirm --clean --windowed --onefile `
  --name "Uninstall" `
  --distpath (Join-Path $Build "uninstaller-dist") `
  --workpath (Join-Path $Build "uninstaller-work") `
  --specpath (Join-Path $Build "spec") `
  (Join-Path $Project "installer\uninstall.py")
if ($LASTEXITCODE -ne 0) { throw "Uninstaller build failed" }
$Uninstaller = Join-Path $Build "uninstaller-dist\Uninstall.exe"

& $Python -m PyInstaller --noconfirm --clean --windowed --onefile `
  --name "1688闲鱼助手_Setup_V5.0.3" `
  --distpath $Release `
  --workpath (Join-Path $Build "setup-work") `
  --specpath (Join-Path $Build "spec") `
  --add-data "$Payload;payload" `
  --add-data "$Uninstaller;payload" `
  (Join-Path $Project "installer\main_setup.py")
if ($LASTEXITCODE -ne 0) { throw "Main installer build failed" }

& $Python -m PyInstaller --noconfirm --clean --windowed --onefile `
  --name "1688闲鱼助手_AI_Setup" `
  --distpath $Release `
  --workpath (Join-Path $Build "ai-work") `
  --specpath (Join-Path $Build "spec") `
  (Join-Path $Project "installer\ai_setup.py")
if ($LASTEXITCODE -ne 0) { throw "AI installer build failed" }

$SourceStage = Join-Path $Build "source-stage\1688闲鱼助手_完整源码_V5.0.3"
New-Item -ItemType Directory -Path $SourceStage -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $Project "app") -Destination $SourceStage -Recurse
New-Item -ItemType Directory -Path (Join-Path $SourceStage "installer") -Force | Out-Null
Get-ChildItem -LiteralPath (Join-Path $Project "installer") -File | Copy-Item -Destination (Join-Path $SourceStage "installer")
Copy-Item -LiteralPath (Join-Path $Project "tests") -Destination $SourceStage -Recurse
Copy-Item -LiteralPath (Join-Path $Project "README.md") -Destination $SourceStage
Copy-Item -LiteralPath (Join-Path $Project "build_release.ps1") -Destination $SourceStage
Get-ChildItem -LiteralPath $SourceStage -Recurse -Directory -Filter "__pycache__" | Remove-Item -Recurse -Force
Get-ChildItem -LiteralPath $SourceStage -Recurse -Directory -Filter "test-data" | Remove-Item -Recurse -Force
Compress-Archive -Path $SourceStage -DestinationPath (Join-Path $Release "1688闲鱼助手_完整源码_V5.0.3.zip") -CompressionLevel Optimal

Get-FileHash -Algorithm SHA256 (Join-Path $Release "*.exe"),(Join-Path $Release "*.zip") | Format-Table Path,Hash
