import os,sys
from pathlib import Path

# PyInstaller onedir applications normally configure these paths itself.  Some
# Windows systems intermittently fail to resolve Qt's sibling DLLs on the first
# launch from a newly extracted directory, so register them explicitly before
# importing PySide6 and keep the directory handles alive for the process life.
_DLL_HANDLES=[]
if getattr(sys,"frozen",False) and os.name=="nt":
    root=Path(getattr(sys,"_MEIPASS",Path(sys.executable).parent/"_internal"))
    for folder in (root,root/"PySide6",root/"shiboken6"):
        if folder.exists():
            try:_DLL_HANDLES.append(os.add_dll_directory(str(folder)))
            except Exception:pass
    plugins=root/"PySide6"/"plugins"
    if plugins.exists():os.environ.setdefault("QT_PLUGIN_PATH",str(plugins))
from PySide6.QtWidgets import QApplication
from core.db import init_db
from core.config import APP_VERSION
from ui.main_window import MainWindow
from ui.changelog import show_whats_new_once

def main():
    init_db()
    app=QApplication(sys.argv)
    app.setApplicationName("1688闲鱼助手")
    app.setApplicationVersion(APP_VERSION)
    w=MainWindow();w.show();show_whats_new_once(w)
    sys.exit(app.exec())

if __name__=="__main__":main()
