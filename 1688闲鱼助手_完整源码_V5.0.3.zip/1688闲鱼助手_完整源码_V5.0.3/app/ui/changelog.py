from __future__ import annotations
import json
from PySide6.QtWidgets import QMessageBox
from core.config import APP_STATE_PATH,APP_VERSION


def show_whats_new_once(parent=None):
    state={}
    try:state=json.loads(APP_STATE_PATH.read_text(encoding="utf-8"))
    except Exception:pass
    if state.get("last_seen_version")==APP_VERSION:return
    QMessageBox.information(parent,"本版本新增功能",(
        "1688 → 闲鱼助手 V5.0.3\n\n"
        "• 修复覆盖升级后旧 ICU 运行库残留导致 QtWidgets 无法启动\n"
        "• 主界面新增“导入V4数据库”，自动读取默认旧版路径\n"
        "• 导入前自动备份 V5，复制旧商品图片，且不修改 V4 原数据库\n"
        "• 新增独立鱼小铺发布通道\n"
        "• 新增鱼小铺商品规格 / SKU、原价、库存和发货设置\n"
        "• 鱼小铺手续费比普通闲鱼高 1%，定价和净利润分渠道计算\n"
        "• 增强 1688 采购价、阶梯价和运费识别；无法确认的运费明确标为未知\n"
        "• 保存商品属性，AI 生成和发布描述会读取属性\n"
        "• 安装包支持识别旧安装路径并覆盖升级，用户数据继续保留\n"
        "• 增强 Windows Qt 运行库加载，并使用独立卸载程序\n\n"
        "• V5 使用独立空白数据库，不读取或修改旧版本商品数据\n\n"
        "所有自动发布仍会保留浏览器页面，最终由你人工检查并点击发布。"
    ))
    state["last_seen_version"]=APP_VERSION
    APP_STATE_PATH.parent.mkdir(parents=True,exist_ok=True)
    APP_STATE_PATH.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding="utf-8")
