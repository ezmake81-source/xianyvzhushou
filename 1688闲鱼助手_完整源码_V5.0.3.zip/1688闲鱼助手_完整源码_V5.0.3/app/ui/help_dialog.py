from __future__ import annotations

from pathlib import Path
from PySide6.QtWidgets import QDialog, QVBoxLayout, QTextBrowser, QHBoxLayout, QPushButton
from core.config import RESOURCE_ROOT


class HelpDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("使用教程")
        self.resize(1000, 760)

        root = QVBoxLayout(self)
        self.browser = QTextBrowser()
        self.browser.setOpenExternalLinks(True)

        help_path = RESOURCE_ROOT / "docs" / "使用教程.html"
        if help_path.exists():
            self.browser.setSource(help_path.as_uri())
        else:
            self.browser.setHtml("<h2>未找到教程文件</h2><p>请确认 docs/使用教程.html 与程序一起存在。</p>")

        root.addWidget(self.browser, 1)

        row = QHBoxLayout()
        row.addStretch(1)
        close_btn = QPushButton("关闭")
        close_btn.clicked.connect(self.accept)
        row.addWidget(close_btn)
        root.addLayout(row)
