from PySide6.QtWidgets import *
from core.diagnostics import run_checks
class DiagnosticsDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent);self.setWindowTitle("系统状态");self.resize(650,430)
        l=QVBoxLayout(self);self.table=QTableWidget(0,3);self.table.setHorizontalHeaderLabels(["项目","状态","说明"]);self.table.horizontalHeader().setStretchLastSection(True);l.addWidget(self.table)
        b=QPushButton("重新检测");b.clicked.connect(self.refresh);l.addWidget(b);self.refresh()
    def refresh(self):
        rows=run_checks();self.table.setRowCount(len(rows))
        for r,(name,ok,info) in enumerate(rows):
            self.table.setItem(r,0,QTableWidgetItem(name));self.table.setItem(r,1,QTableWidgetItem("✓" if ok else "✗"));self.table.setItem(r,2,QTableWidgetItem(info))
