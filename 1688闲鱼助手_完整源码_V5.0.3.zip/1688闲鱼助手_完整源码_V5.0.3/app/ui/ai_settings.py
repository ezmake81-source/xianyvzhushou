from __future__ import annotations

from PySide6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QListWidget, QPushButton,
    QLineEdit, QFileDialog, QMessageBox, QGroupBox, QFormLayout
)

from core.ai import ollama_available, ollama_models
from core.config import OLLAMA_MODEL
from core.ollama_manager import (
    current_model_dir, set_model_dir, open_model_dir, restart_ollama, model_dir_info
)


class AISettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("AI 设置")
        self.resize(720, 520)

        root = QVBoxLayout(self)

        status_group = QGroupBox("本地 AI 状态")
        status_layout = QVBoxLayout(status_group)
        self.status = QLabel()
        self.status.setWordWrap(True)
        status_layout.addWidget(self.status)

        self.models = QListWidget()
        status_layout.addWidget(QLabel("已安装模型"))
        status_layout.addWidget(self.models)
        root.addWidget(status_group)

        dir_group = QGroupBox("Ollama 模型存储目录")
        dir_layout = QFormLayout(dir_group)

        path_row = QHBoxLayout()
        self.dir_edit = QLineEdit(str(current_model_dir()))
        browse = QPushButton("选择目录")
        browse.clicked.connect(self.choose_dir)
        path_row.addWidget(self.dir_edit, 1)
        path_row.addWidget(browse)
        dir_layout.addRow("模型目录", path_row)

        self.dir_info = QLabel()
        self.dir_info.setWordWrap(True)
        dir_layout.addRow("说明", self.dir_info)

        btn_row = QHBoxLayout()
        apply_btn = QPushButton("应用目录")
        apply_btn.clicked.connect(self.apply_dir)
        open_btn = QPushButton("打开目录")
        open_btn.clicked.connect(self.open_dir)
        restart_btn = QPushButton("重启 Ollama")
        restart_btn.clicked.connect(self.restart)
        btn_row.addWidget(apply_btn)
        btn_row.addWidget(open_btn)
        btn_row.addWidget(restart_btn)
        btn_row.addStretch(1)
        dir_layout.addRow(btn_row)

        root.addWidget(dir_group)

        bottom = QHBoxLayout()
        refresh_btn = QPushButton("刷新状态")
        refresh_btn.clicked.connect(self.refresh)
        bottom.addWidget(refresh_btn)
        bottom.addStretch(1)
        close_btn = QPushButton("关闭")
        close_btn.clicked.connect(self.accept)
        bottom.addWidget(close_btn)
        root.addLayout(bottom)

        self.refresh()

    def choose_dir(self):
        start = self.dir_edit.text().strip() or str(current_model_dir())
        p = QFileDialog.getExistingDirectory(self, "选择 Ollama 模型目录", start)
        if p:
            self.dir_edit.setText(p)

    def apply_dir(self):
        path = self.dir_edit.text().strip()
        if not path:
            QMessageBox.information(self, "提示", "请先选择一个目录。")
            return

        ok, msg = set_model_dir(path)
        if ok:
            QMessageBox.information(
                self,
                "设置成功",
                msg + "\n\n新的目录需要重新启动 Ollama 后才会生效。\n"
                      "已经下载到旧目录的模型不会自动移动。"
            )
        else:
            QMessageBox.warning(self, "设置失败", msg)
        self.refresh()

    def open_dir(self):
        ok, msg = open_model_dir(self.dir_edit.text().strip())
        if not ok:
            QMessageBox.warning(self, "无法打开目录", msg)

    def restart(self):
        ok, msg = restart_ollama()
        QMessageBox.information(self, "Ollama", msg) if ok else QMessageBox.warning(self, "Ollama", msg)
        self.refresh()

    def refresh(self):
        ok = ollama_available()
        models = ollama_models()
        info = model_dir_info()

        self.status.setText(
            f"Ollama：{'已连接' if ok else '未连接'}\n"
            f"当前配置模型：{OLLAMA_MODEL}\n"
            f"模型目录：{info['path']}\n"
            f"目录剩余空间：{info['free_gb']:.1f} GB"
        )

        self.models.clear()
        self.models.addItems(models or ["未检测到本地模型"])

        self.dir_edit.setText(info["path"])
        self.dir_info.setText(
            "建议把大模型放在空间较大的 D 盘，例如 D:\\AI\\OllamaModels。\n"
            "点击“应用目录”会设置 Windows 用户环境变量 OLLAMA_MODELS；"
            "应用后请重启 Ollama。已有模型不会自动迁移。"
        )
