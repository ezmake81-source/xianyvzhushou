from PySide6.QtWidgets import *
class AddDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent);self.setWindowTitle("添加商品");self.resize(560,220)
        l=QVBoxLayout(self);self.mode=QComboBox();self.mode.addItems(["从1688链接采集","手动创建商品"]);self.url=QLineEdit();self.url.setPlaceholderText("粘贴1688商品链接")
        l.addWidget(QLabel("添加方式"));l.addWidget(self.mode);l.addWidget(self.url)
        bb=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);bb.accepted.connect(self.accept);bb.rejected.connect(self.reject);l.addWidget(bb)
    def result_data(self):return self.mode.currentIndex(),self.url.text().strip()
