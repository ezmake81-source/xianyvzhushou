from __future__ import annotations
import shutil,time
from pathlib import Path
from PySide6.QtCore import Qt,QSize
from PySide6.QtGui import QPixmap,QIcon
from PySide6.QtWidgets import *
from core.config import IMAGE_DIR

class ImageManagerDialog(QDialog):
    def __init__(self,images,parent=None):
        super().__init__(parent);self.setWindowTitle("图片管理");self.resize(1000,700)
        self._images=list(images or [])
        lay=QVBoxLayout(self);split=QSplitter(Qt.Horizontal)
        left=QWidget();ll=QVBoxLayout(left)
        self.list=QListWidget();self.list.setViewMode(QListWidget.IconMode);self.list.setIconSize(QSize(110,110));self.list.setGridSize(QSize(135,145))
        self.list.currentRowChanged.connect(self.show_current);ll.addWidget(self.list,1)
        row=QHBoxLayout()
        for txt,fn in [("添加",self.add),("替换",self.replace),("删除",self.delete),("设为主图",self.primary),("前移",lambda:self.move(-1)),("后移",lambda:self.move(1))]:
            b=QPushButton(txt);b.clicked.connect(fn);row.addWidget(b)
        ll.addLayout(row)
        right=QWidget();rl=QVBoxLayout(right)
        self.preview=QLabel("选择缩略图查看大图");self.preview.setAlignment(Qt.AlignCenter);self.preview.setMinimumSize(500,500);rl.addWidget(self.preview,1)
        self.path=QLabel();self.path.setWordWrap(True);rl.addWidget(self.path)
        split.addWidget(left);split.addWidget(right);split.setSizes([430,570]);lay.addWidget(split,1)
        bb=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);bb.accepted.connect(self.accept);bb.rejected.connect(self.reject);lay.addWidget(bb)
        self.reload()

    def images(self):return list(self._images)
    def reload(self,row=0):
        self.list.clear()
        for p in self._images:
            path=Path(p);it=QListWidgetItem(path.name);it.setToolTip(str(path))
            if path.exists():
                pix=QPixmap(str(path))
                if not pix.isNull():it.setIcon(QIcon(pix.scaled(110,110,Qt.KeepAspectRatio,Qt.SmoothTransformation)))
            self.list.addItem(it)
        if self._images:self.list.setCurrentRow(max(0,min(row,len(self._images)-1)))
    def show_current(self,row):
        if row<0 or row>=len(self._images):return
        p=Path(self._images[row]);self.path.setText(str(p))
        pix=QPixmap(str(p)) if p.exists() else QPixmap()
        if pix.isNull():self.preview.setText("图片不可用");self.preview.setPixmap(QPixmap())
        else:self.preview.setPixmap(pix.scaled(max(200,self.preview.width()-20),max(200,self.preview.height()-20),Qt.KeepAspectRatio,Qt.SmoothTransformation))
    def _copy(self,p):
        src=Path(p);d=IMAGE_DIR/"manual";d.mkdir(parents=True,exist_ok=True);t=d/f"{int(time.time()*1000)}_{src.name}";shutil.copy2(src,t);return str(t)
    def add(self):
        ps,_=QFileDialog.getOpenFileNames(self,"添加图片","","Images (*.jpg *.jpeg *.png *.webp *.bmp)")
        for p in ps:self._images.append(self._copy(p))
        self.reload(max(0,len(self._images)-len(ps)))
    def replace(self):
        r=self.list.currentRow()
        if r<0:return
        p,_=QFileDialog.getOpenFileName(self,"替换图片","","Images (*.jpg *.jpeg *.png *.webp *.bmp)")
        if p:self._images[r]=self._copy(p);self.reload(r)
    def delete(self):
        r=self.list.currentRow()
        if r>=0:self._images.pop(r);self.reload(max(0,r-1))
    def primary(self):
        r=self.list.currentRow()
        if r>0:self._images.insert(0,self._images.pop(r));self.reload(0)
    def move(self,d):
        r=self.list.currentRow();t=r+d
        if r>=0 and 0<=t<len(self._images):
            self._images[r],self._images[t]=self._images[t],self._images[r];self.reload(t)
