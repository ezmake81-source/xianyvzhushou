from __future__ import annotations
from PySide6.QtGui import QDoubleValidator
from PySide6.QtWidgets import *
from core.description import description_with_attributes
from core.pricing import calc_price,derive_parameter,metrics
from .image_manager import ImageManagerDialog


class ProductDialog(QDialog):
    def __init__(self,p=None,parent=None):
        super().__init__(parent);self.p=p or {};self._images=list(self.p.get("images",[]));self._syncing=False
        self.setWindowTitle("商品编辑");self.resize(960,850)
        root=QVBoxLayout(self);self.tabs=QTabWidget();root.addWidget(self.tabs,1)
        self._build_basic();self._build_attributes();self._build_skus();self._build_shipping()
        bb=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);bb.accepted.connect(self.accept);bb.rejected.connect(self.reject);root.addWidget(bb)
        for w in (self.cost,self.shipping_cost,self.val):w.textEdited.connect(self.sync_from_cost_or_param)
        self.sale.textEdited.connect(self.sync_from_sale);self.mode.currentIndexChanged.connect(self.mode_changed)
        self.channel.currentIndexChanged.connect(self.channel_changed);self.normal_fee.textEdited.connect(self.fee_changed)
        self.channel_changed();self.update_metric()

    def _build_basic(self):
        w=QWidget();lay=QVBoxLayout(w);form=QFormLayout()
        self.url=QLineEdit(self.p.get("source_url",""));self.source=QLineEdit(self.p.get("source_title",""));self.shop=QLineEdit(self.p.get("shop_name",""))
        self.ai=QLineEdit(self.p.get("ai_title",""));self.desc=QTextEdit(self.p.get("description",""));self.ins=QTextEdit(self.p.get("ai_instruction",""))
        self.channel=QComboBox();self.channel.addItem("普通闲鱼","normal");self.channel.addItem("鱼小铺","fishshop");self.channel.setCurrentIndex(max(0,self.channel.findData(self.p.get("publish_channel","normal"))))
        self.fee_warning=QLabel("⚠ 鱼小铺渠道手续费比普通闲鱼高 1%。售价与净利润将按所选渠道计算。")
        self.fee_warning.setWordWrap(True);self.fee_warning.setStyleSheet("background:#fff1f0;color:#b42318;border:2px solid #f04438;padding:10px;font-weight:bold;")
        is_new=not bool(self.p);default_mode="margin" if is_new else self.p.get("pricing_mode","margin");default_value=30.0 if is_new else float(self.p.get("pricing_value",30) or 30)
        self.cost=self._money(self.p.get("cost",0));self.shipping_cost=self._money(self.p.get("shipping_cost") or 0)
        self.shipping_unknown=QCheckBox("1688 运费尚未可靠识别（不把未知运费伪装为 0）");self.shipping_unknown.setChecked(bool(self.p.get("shipping_cost_unknown",True)))
        self.mode=QComboBox()
        for t,d in [("毛利率 %","margin"),("倍率","multiplier"),("固定加价","profit"),("固定售价","fixed")]:self.mode.addItem(t,d)
        self.mode.setCurrentIndex(max(0,self.mode.findData(default_mode)))
        self.val=self._money(default_value);self.sale=self._money(self.p.get("sale_price",0));self.original=self._money(self.p.get("original_price",0))
        self.normal_fee=self._money(float(self.p.get("normal_fee_rate",0))*100);self.fish_fee=self._money((float(self.p.get("normal_fee_rate",0))+0.01)*100);self.fish_fee.setReadOnly(True)
        self.status=QComboBox();self.status.addItems(["待处理","已采集","待发布","处理中","已填充","已发布","失败"]);self.status.setCurrentText(self.p.get("status","待处理"))
        for label,field in [("1688链接",self.url),("原始标题",self.source),("店铺",self.shop),("AI标题",self.ai),("商品描述",self.desc),("AI额外要求",self.ins),("默认发布渠道",self.channel)]:form.addRow(label,field)
        form.addRow("",self.fee_warning);form.addRow("采购价",self.cost);form.addRow("单件运费成本",self.shipping_cost);form.addRow("",self.shipping_unknown)
        form.addRow("定价方式",self.mode);form.addRow("定价参数",self.val);form.addRow("售价",self.sale);form.addRow("鱼小铺原价",self.original)
        fees=QHBoxLayout();fees.addWidget(QLabel("普通闲鱼"));fees.addWidget(self.normal_fee);fees.addWidget(QLabel("%   鱼小铺"));fees.addWidget(self.fish_fee);fees.addWidget(QLabel("%"));form.addRow("渠道费率",fees)
        form.addRow("状态",self.status);lay.addLayout(form)
        self.metric=QLabel();self.metric.setStyleSheet("font-weight:bold;padding:8px;background:#f5f7fa");lay.addWidget(self.metric)
        self.imgbtn=QPushButton();self.imgbtn.clicked.connect(self.images);lay.addWidget(self.imgbtn);self.reload_images()
        self.tabs.addTab(w,"基本与定价")

    def _build_attributes(self):
        w=QWidget();lay=QVBoxLayout(w)
        self.append_attrs=QCheckBox("发布/AI生成时自动把商品属性整理到描述末尾");self.append_attrs.setChecked(bool(self.p.get("append_attrs",True)));lay.addWidget(self.append_attrs)
        self.attrs=QTableWidget(0,2);self.attrs.setHorizontalHeaderLabels(["属性名","属性值"]);self.attrs.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch);lay.addWidget(self.attrs,1)
        for k,v in (self.p.get("attrs") or {}).items():self._add_attr(str(k),str(v))
        row=QHBoxLayout();add=QPushButton("新增属性");add.clicked.connect(lambda:self._add_attr("",""));remove=QPushButton("删除选中");remove.clicked.connect(lambda:self._remove_rows(self.attrs));preview=QPushButton("整理进描述预览");preview.clicked.connect(self.preview_attrs)
        for b in (add,remove,preview):row.addWidget(b)
        row.addStretch();lay.addLayout(row);self.tabs.addTab(w,"商品属性")

    def _build_skus(self):
        w=QWidget();lay=QVBoxLayout(w);tip=QLabel("仅鱼小铺通道使用。普通闲鱼继续采用简化发布，不写入商品规格。")
        tip.setStyleSheet("color:#475467;padding:6px");lay.addWidget(tip)
        self.skus=QTableWidget(0,5);self.skus.setHorizontalHeaderLabels(["规格组合","售价","原价","库存","SKU图片路径"]);self.skus.horizontalHeader().setSectionResizeMode(0,QHeaderView.Stretch);self.skus.horizontalHeader().setSectionResizeMode(4,QHeaderView.Stretch);lay.addWidget(self.skus,1)
        for x in self.p.get("sku",[]) or []:self._add_sku(x)
        row=QHBoxLayout();add=QPushButton("新增规格");add.clicked.connect(lambda:self._add_sku({}));remove=QPushButton("删除选中");remove.clicked.connect(lambda:self._remove_rows(self.skus));copy=QPushButton("从商品数据补全空价格/库存");copy.clicked.connect(self.fill_sku_prices)
        for b in (add,remove,copy):row.addWidget(b)
        row.addStretch();lay.addLayout(row);self.tabs.addTab(w,"鱼小铺 SKU")

    def _build_shipping(self):
        w=QWidget();form=QFormLayout(w)
        self.stock=QLineEdit(str(self.p.get("stock","")));self.video=QLineEdit(self.p.get("video_path",""));browse=QPushButton("选择视频");browse.clicked.connect(self.choose_video);vr=QHBoxLayout();vr.addWidget(self.video,1);vr.addWidget(browse)
        self.shipping_mode=QComboBox()
        for t,d in [("包邮","free"),("按距离计费","distance"),("一口价","fixed"),("运费模板","template"),("无需邮寄","none")]:self.shipping_mode.addItem(t,d)
        self.shipping_mode.setCurrentIndex(max(0,self.shipping_mode.findData(self.p.get("shipping_mode","free"))))
        self.shipping_template=QLineEdit(self.p.get("shipping_template",""));self.location=QLineEdit(self.p.get("location",""))
        form.addRow("总库存",self.stock);form.addRow("宝贝视频",vr);form.addRow("发货方式",self.shipping_mode);form.addRow("运费/模板名称",self.shipping_template);form.addRow("宝贝所在地",self.location)
        self.tabs.addTab(w,"鱼小铺发货设置")

    def _money(self,value):
        w=QLineEdit("" if value is None else str(value));w.setValidator(QDoubleValidator(0,999999,4,self));return w
    def num(self,w):
        try:return float(w.text())
        except:return 0.0
    def fee_rate(self):return self.num(self.fish_fee if self.channel.currentData()=="fishshop" else self.normal_fee)/100
    def _set_text(self,w,value,decimals=2):w.setText(f"{float(value):.{decimals}f}".rstrip("0").rstrip("."))
    def sync_from_cost_or_param(self,*_):
        if self._syncing:return
        self._syncing=True
        try:self._set_text(self.sale,calc_price(self.num(self.cost),self.mode.currentData(),self.num(self.val),self.num(self.shipping_cost),self.fee_rate()));self.update_metric()
        finally:self._syncing=False
    def sync_from_sale(self,*_):
        if self._syncing:return
        self._syncing=True
        try:self._set_text(self.val,derive_parameter(self.num(self.cost),self.num(self.sale),self.mode.currentData(),self.num(self.shipping_cost),self.fee_rate()));self.update_metric()
        finally:self._syncing=False
    def mode_changed(self,*_):self.sync_from_sale()
    def channel_changed(self,*_):
        self.fee_warning.setVisible(self.channel.currentData()=="fishshop")
        if hasattr(self,"sale"):self.sync_from_cost_or_param()
    def fee_changed(self,*_):
        self._set_text(self.fish_fee,self.num(self.normal_fee)+1,2);self.sync_from_cost_or_param()
    def update_metric(self,*_):
        profit,margin,fee=metrics(self.num(self.cost),self.num(self.sale),self.num(self.shipping_cost),self.fee_rate())
        channel="鱼小铺" if self.channel.currentData()=="fishshop" else "普通闲鱼";unknown="；运费未知，利润可能偏高" if self.shipping_unknown.isChecked() else ""
        self.metric.setText(f"{channel}｜渠道手续费：{fee:.2f} 元｜预计净利润：{profit:.2f} 元｜净利率：{margin:.1f}%{unknown}")
    def _add_attr(self,k,v):
        r=self.attrs.rowCount();self.attrs.insertRow(r);self.attrs.setItem(r,0,QTableWidgetItem(k));self.attrs.setItem(r,1,QTableWidgetItem(v))
    def _add_sku(self,x):
        r=self.skus.rowCount();self.skus.insertRow(r);vals=[x.get("name",x.get("spec","")),x.get("price",""),x.get("original_price",""),x.get("stock",""),x.get("image","")]
        for c,v in enumerate(vals):self.skus.setItem(r,c,QTableWidgetItem(str(v)))
    def _remove_rows(self,table):
        for r in sorted({x.row() for x in table.selectedIndexes()},reverse=True):table.removeRow(r)
    def preview_attrs(self):self.desc.setPlainText(description_with_attributes(self.desc.toPlainText(),self.attr_data(),True))
    def fill_sku_prices(self):
        for r in range(self.skus.rowCount()):
            if not (self.skus.item(r,1) and self.skus.item(r,1).text().strip()):self.skus.setItem(r,1,QTableWidgetItem(self.sale.text()))
            if not (self.skus.item(r,3) and self.skus.item(r,3).text().strip()):self.skus.setItem(r,3,QTableWidgetItem(self.stock.text()))
    def choose_video(self):
        p,_=QFileDialog.getOpenFileName(self,"选择宝贝视频","","Video (*.mp4 *.mov *.avi *.mkv)")
        if p:self.video.setText(p)
    def images(self):
        d=ImageManagerDialog(self._images,self)
        if d.exec():self._images=d.images();self.reload_images()
    def reload_images(self):self.imgbtn.setText(f"管理图片（{len(self._images)} 张；普通闲鱼前6张，鱼小铺最多尝试9张）")
    def attr_data(self):
        out={}
        for r in range(self.attrs.rowCount()):
            k=self.attrs.item(r,0).text().strip() if self.attrs.item(r,0) else "";v=self.attrs.item(r,1).text().strip() if self.attrs.item(r,1) else ""
            if k and v:out[k]=v
        return out
    def sku_data(self):
        out=[]
        for r in range(self.skus.rowCount()):
            vals=[self.skus.item(r,c).text().strip() if self.skus.item(r,c) else "" for c in range(5)]
            if vals[0]:out.append({"name":vals[0],"price":self._float(vals[1]),"original_price":self._float(vals[2]),"stock":vals[3],"image":vals[4]})
        return out
    def _float(self,x):
        try:return float(x)
        except:return 0
    def data(self):
        attrs=self.attr_data();desc=self.desc.toPlainText().strip()
        if self.append_attrs.isChecked():desc=description_with_attributes(desc,attrs,True)
        return {"source_url":self.url.text().strip(),"source_title":self.source.text().strip(),"shop_name":self.shop.text().strip(),"ai_title":self.ai.text().strip(),"description":desc,"ai_instruction":self.ins.toPlainText().strip(),"cost":self.num(self.cost),"shipping_cost":None if self.shipping_unknown.isChecked() and not self.shipping_cost.text().strip() else self.num(self.shipping_cost),"shipping_cost_unknown":self.shipping_unknown.isChecked(),"pricing_mode":self.mode.currentData(),"pricing_value":self.num(self.val),"sale_price":self.num(self.sale),"original_price":self.num(self.original),"publish_channel":self.channel.currentData(),"normal_fee_rate":self.num(self.normal_fee)/100,"fishshop_fee_rate":self.num(self.fish_fee)/100,"append_attrs":self.append_attrs.isChecked(),"status":self.status.currentText(),"images":self._images,"attrs":attrs,"sku":self.sku_data(),"stock":self.stock.text().strip(),"video_path":self.video.text().strip(),"shipping_mode":self.shipping_mode.currentData(),"shipping_template":self.shipping_template.text().strip(),"location":self.location.text().strip()}
