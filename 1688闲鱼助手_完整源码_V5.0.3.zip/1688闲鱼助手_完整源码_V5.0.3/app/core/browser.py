from __future__ import annotations

from contextlib import contextmanager
from playwright.sync_api import sync_playwright
from .config import BROWSER_HEADLESS


def _launch_context(p, profile_dir, headless):
    common = dict(
        user_data_dir=str(profile_dir),
        headless=headless,
        locale="zh-CN",
        viewport={"width": 1440, "height": 1000},
        args=[
            "--disable-blink-features=AutomationControlled",
            "--start-maximized",
        ],
    )

    # EXE 发行版优先使用 Windows 自带/已安装的 Microsoft Edge。
    # 这样目标电脑不需要额外下载 Playwright Chromium。
    try:
        return p.chromium.launch_persistent_context(channel="msedge", **common)
    except Exception as edge_error:
        # 开发环境/极少数没有 Edge 的机器再尝试 Playwright 自带 Chromium。
        try:
            return p.chromium.launch_persistent_context(**common)
        except Exception as chromium_error:
            raise RuntimeError(
                "无法启动浏览器。\n"
                "请确认 Windows 已安装 Microsoft Edge；"
                "如果是源码开发环境，可执行 playwright install chromium。\n\n"
                f"Edge错误：{edge_error}\n"
                f"Chromium错误：{chromium_error}"
            )


@contextmanager
def persistent_browser(profile_dir, headless=None):
    headless = BROWSER_HEADLESS if headless is None else headless
    profile_dir.mkdir(parents=True, exist_ok=True)

    with sync_playwright() as p:
        ctx = _launch_context(p, profile_dir, headless)
        try:
            yield ctx
        finally:
            try:
                ctx.close()
            except Exception:
                pass
