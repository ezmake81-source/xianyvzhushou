def calc_price(cost:float, mode:str, value:float, shipping_cost:float=0,
               fee_rate:float=0)->float:
    """Calculate a sale price while keeping the old result when fee/shipping are zero.

    fee_rate is a decimal (0.01 means 1%).  Margin/profit/multiplier modes gross-up
    the target price so the requested result remains after the channel fee.
    """
    cost=max(0.0,float(cost or 0))+max(0.0,float(shipping_cost or 0))
    value=float(value or 0); fee=min(max(float(fee_rate or 0),0),0.95)
    net=max(0.01,1-fee)
    if mode=='multiplier': price=cost*value/net
    elif mode=='margin':
        m=min(max(value/100.0,0),0.94); price=cost/(1-m-fee) if m+fee<1 else cost
    elif mode=='profit': price=(cost+value)/net
    elif mode=='fixed': price=value
    else: price=cost
    return round(max(0.0,price),2)

def derive_parameter(cost:float, sale:float, mode:str, shipping_cost:float=0,
                     fee_rate:float=0)->float:
    cost=max(0.0,float(cost or 0))+max(0.0,float(shipping_cost or 0))
    sale=max(0.0,float(sale or 0)); fee=min(max(float(fee_rate or 0),0),0.95)
    net_sale=sale*(1-fee)
    if mode=='multiplier': return round(net_sale/cost,4) if cost>0 else 0.0
    if mode=='margin': return round(((net_sale-cost)/sale)*100,2) if sale>0 else 0.0
    if mode=='profit': return round(net_sale-cost,2)
    if mode=='fixed': return round(sale,2)
    return 0.0

def metrics(cost:float, sale:float, shipping_cost:float=0, fee_rate:float=0):
    cost=float(cost or 0); shipping=float(shipping_cost or 0); sale=float(sale or 0)
    fee=round(sale*float(fee_rate or 0),2); profit=sale-fee-cost-shipping
    margin=(profit/sale*100) if sale>0 else 0
    return round(profit,2), round(margin,2), fee
