from __future__ import annotations
import csv
from . import db

FIELDS=["id","source_url","offer_id","source_title","shop_name","ai_title","cost","shipping_cost","shipping_cost_unknown","sale_price","original_price","pricing_mode","pricing_value","publish_channel","normal_fee_rate","fishshop_fee_rate","stock","shipping_mode","location","status"]

def export_csv(path):
    rows=db.list_products()
    with open(path,"w",encoding="utf-8-sig",newline="") as f:
        w=csv.DictWriter(f,fieldnames=FIELDS)
        w.writeheader()
        for r in rows:w.writerow({k:r.get(k,"") for k in FIELDS})

def import_csv(path):
    count=0
    with open(path,"r",encoding="utf-8-sig",newline="") as f:
        for row in csv.DictReader(f):
            if row.get("id"):
                try:
                    pid=int(row["id"])
                    if db.get_product(pid):
                        db.update_product(pid,row);count+=1;continue
                except:pass
            db.create_product(row);count+=1
    return count
