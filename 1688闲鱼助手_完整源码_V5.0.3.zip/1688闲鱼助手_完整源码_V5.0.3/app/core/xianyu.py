from __future__ import annotations

from datetime import datetime
from pathlib import Path
import json
import time

from .browser import persistent_browser
from .config import (
    PROFILE_XIANYU,
    XIANYU_HOME_URL,
    XIANYU_PUBLISH_URL,
    XIANYU_AUTH_STATE,
    LOG_DIR,
)

TITLE_SELECTORS = [
    "textarea[placeholder*='标题']",
    "input[placeholder*='标题']",
    "input[maxlength='30']",
    "input[maxlength='50']",
]
DESC_SELECTORS = [
    "textarea[placeholder*='描述']",
    "textarea[placeholder*='宝贝']",
    "textarea",
    "[contenteditable='true']",
]
PRICE_SELECTORS = [
    "input[placeholder*='价格']",
    "input[placeholder*='售价']",
    "input[type='number']",
]

LOGIN_NEGATIVE_WORDS = [
    "扫码登录", "短信登录", "账号登录", "密码登录",
    "立即登录", "登录/注册", "请登录", "手机淘宝扫码",
]
LOGIN_POSITIVE_WORDS = [
    "订单", "个人主页", "我的闲鱼", "退出登录", "账号管理",
]
AUTH_COOKIE_HINTS = {
    "tracknick", "lgc", "unb", "cookie2", "_tb_token_", "sgcookie",
    "cna", "havana_lgc2_77", "munb",
}


def _visible_text(page, text: str) -> bool:
    try:
        loc = page.get_by_text(text, exact=False)
        for i in range(min(loc.count(), 15)):
            try:
                if loc.nth(i).is_visible():
                    return True
            except Exception:
                pass
    except Exception:
        pass
    return False


def _visible_any(page, words) -> bool:
    return any(_visible_text(page, x) for x in words)


def _login_dialog_visible(page) -> bool:
    return _visible_any(page, LOGIN_NEGATIVE_WORDS)


def _avatar_visible(page) -> bool:
    selectors = [
        "img[src*='avatar']",
        "img[class*='avatar']",
        "[class*='avatar'] img",
        "[class*='user'] img",
        "[class*='account'] img",
        "[class*='nick']",
        "[class*='user-name']",
        "[class*='username']",
    ]
    for sel in selectors:
        try:
            loc = page.locator(sel)
            for i in range(min(loc.count(), 10)):
                try:
                    if loc.nth(i).is_visible():
                        return True
                except Exception:
                    pass
        except Exception:
            pass
    return False


def _auth_cookie_score(ctx) -> int:
    try:
        cookies = ctx.cookies()
    except Exception:
        return 0
    score = 0
    for c in cookies:
        name = (c.get("name") or "").lower()
        value = c.get("value") or ""
        domain = (c.get("domain") or "").lower()
        if not value:
            continue
        if not any(x in domain for x in ("goofish.com", "taobao.com", "tmall.com", "alibaba.com")):
            continue
        if name in AUTH_COOKIE_HINTS:
            score += 1
    return score


def login_state(page, ctx) -> str:
    if _login_dialog_visible(page):
        return "logged_out"

    cookie_score = _auth_cookie_score(ctx)
    avatar = _avatar_visible(page)
    order_visible = _visible_text(page, "订单")
    strong_positive = _visible_any(page, ["个人主页", "我的闲鱼", "退出登录", "账号管理"])

    if avatar and order_visible:
        return "logged_in"
    if strong_positive and cookie_score >= 1:
        return "logged_in"
    if cookie_score >= 2:
        return "logged_in"
    if order_visible and cookie_score >= 1:
        return "logged_in"
    return "unknown"


def login_evidence(page, ctx) -> str:
    try:
        return (
            f"可见登录弹窗={'是' if _login_dialog_visible(page) else '否'}；"
            f"头像/账号区域={'是' if _avatar_visible(page) else '否'}；"
            f"订单入口={'是' if _visible_text(page,'订单') else '否'}；"
            f"账号Cookie命中={_auth_cookie_score(ctx)}"
        )
    except Exception:
        return "无法读取登录证据"


def _save_auth_state(ctx) -> bool:
    """
    双保险：
    1. Playwright persistent profile 本身会保存浏览器数据
    2. 再额外导出 cookies + localStorage 到 xianyu_auth_state.json
    """
    try:
        XIANYU_AUTH_STATE.parent.mkdir(parents=True, exist_ok=True)
        ctx.storage_state(path=str(XIANYU_AUTH_STATE))
        return XIANYU_AUTH_STATE.exists()
    except Exception:
        return False


def _restore_auth_state(ctx) -> bool:
    """
    先恢复 Cookie。localStorage 会在页面进入 goofish.com 后再恢复。
    """
    if not XIANYU_AUTH_STATE.exists():
        return False
    try:
        data = json.loads(XIANYU_AUTH_STATE.read_text(encoding="utf-8"))
        cookies = data.get("cookies", [])
        if cookies:
            ctx.add_cookies(cookies)
        return True
    except Exception:
        return False


def _restore_local_storage(page) -> bool:
    if not XIANYU_AUTH_STATE.exists():
        return False
    try:
        data = json.loads(XIANYU_AUTH_STATE.read_text(encoding="utf-8"))
        origin_now = page.evaluate("location.origin")
        for origin in data.get("origins", []):
            if origin.get("origin") != origin_now:
                continue
            items = origin.get("localStorage", [])
            page.evaluate(
                """items => {
                    for (const x of items) localStorage.setItem(x.name, x.value);
                }""",
                items,
            )
            return bool(items)
    except Exception:
        pass
    return False


def _goto_with_restored_auth(page, ctx, url: str):
    restored = _restore_auth_state(ctx)
    page.goto(url, wait_until="domcontentloaded", timeout=90000)
    page.wait_for_timeout(1200)

    # storage_state 中的 localStorage 不能直接灌入 persistent context，
    # 因此进入目标 origin 后再显式恢复并刷新一次。
    if restored and _restore_local_storage(page):
        page.reload(wait_until="domcontentloaded", timeout=90000)
        page.wait_for_timeout(1200)


def _wait_for_login(page, ctx, timeout_sec=300):
    end = time.time() + timeout_sec
    consecutive = 0
    last_state = "unknown"

    while time.time() < end:
        try:
            if page.is_closed():
                return "closed", last_state
            state = login_state(page, ctx)
            last_state = state
        except Exception:
            return "closed", last_state

        if state == "logged_in":
            consecutive += 1
            if consecutive >= 2:
                return "logged_in", state
        else:
            consecutive = 0

        try:
            page.wait_for_timeout(1200)
        except Exception:
            return "closed", last_state

    return "timeout", last_state


def _stabilize_and_save_login(page, ctx):
    """
    登录完成后不要立刻关闭浏览器。
    等待 Cookie/localStorage/IndexedDB 等浏览器状态落盘，然后导出 storage_state。
    """
    try:
        page.wait_for_timeout(5000)
    except Exception:
        pass

    saved = _save_auth_state(ctx)

    # 再访问发布页做一次实际会话验证。
    publish_ok = False
    try:
        page.goto(XIANYU_PUBLISH_URL, wait_until="domcontentloaded", timeout=90000)
        page.wait_for_timeout(2500)
        state = login_state(page, ctx)
        publish_ok = state == "logged_in"
        if publish_ok:
            _save_auth_state(ctx)
    except Exception:
        pass

    return saved, publish_ok


def login_xianyu(timeout_sec=300):
    states = []

    try:
        with persistent_browser(PROFILE_XIANYU, False) as ctx:
            page = ctx.pages[0] if ctx.pages else ctx.new_page()

            try:
                _goto_with_restored_auth(page, ctx, XIANYU_HOME_URL)
                states.append("已打开闲鱼")
            except Exception:
                return {
                    "ok": False,
                    "states": ["闲鱼浏览器被关闭或页面打开失败，请重新点击“闲鱼登录”。"],
                }

            state = login_state(page, ctx)
            states.append("检测依据：" + login_evidence(page, ctx))

            if state == "logged_in":
                saved, publish_ok = _stabilize_and_save_login(page, ctx)
                states.append("已确认闲鱼处于登录状态。")
                states.append("已保存独立登录状态文件。" if saved else "浏览器 Profile 已保存，额外登录状态文件保存失败。")
                if publish_ok:
                    states.append("已验证发布页仍保持登录状态。")
                else:
                    states.append("发布页登录验证未通过；下次发布时会再次恢复登录状态。")
                return {"ok": True, "states": states}

            if state == "logged_out":
                states.append("检测到可见的登录窗口，请完成扫码/账号登录。")
            else:
                states.append("当前状态无法确认，请在浏览器中完成或确认闲鱼登录。")

            states.append(f"程序保持浏览器打开并等待，最长 {timeout_sec} 秒。")
            result, _ = _wait_for_login(page, ctx, timeout_sec)

            if result == "logged_in":
                states.append("检测到登录成功，正在等待登录状态完全写入浏览器...")
                saved, publish_ok = _stabilize_and_save_login(page, ctx)
                states.append("登录状态文件已保存。" if saved else "登录状态文件保存失败，但浏览器 Profile 仍会保留。")
                if publish_ok:
                    states.append("发布页登录验证成功。之后点击“闲鱼填充”应直接进入发布页。")
                else:
                    states.append("发布页验证未通过；程序发布时会再次恢复 Cookie/localStorage。")
                return {"ok": True, "states": states}

            if result == "closed":
                states.append("浏览器窗口被关闭，登录检测已停止。")
                return {"ok": False, "states": states}

            states.append("等待登录超时。")
            return {"ok": False, "states": states}

    except Exception as e:
        return {"ok": False, "states": states + [f"登录检测异常：{e}"]}



def _element_meta(item):
    """读取可编辑元素的可见文本/周边标签，用于闲鱼页面改版后的自适应定位。"""
    try:
        return item.evaluate(
            """el => {
                const rect = el.getBoundingClientRect();
                let parentTexts = [];
                let p = el.parentElement;
                for (let i = 0; p && i < 3; i++, p = p.parentElement) {
                    const t = (p.innerText || '').trim().replace(/\\s+/g, ' ');
                    if (t) parentTexts.push(t.slice(0, 220));
                }
                return {
                    tag: (el.tagName || '').toLowerCase(),
                    type: el.getAttribute('type') || '',
                    placeholder: el.getAttribute('placeholder') || '',
                    aria: el.getAttribute('aria-label') || '',
                    name: el.getAttribute('name') || '',
                    id: el.id || '',
                    cls: el.className || '',
                    inputmode: el.getAttribute('inputmode') || '',
                    maxlength: el.getAttribute('maxlength') || '',
                    contenteditable: el.getAttribute('contenteditable') || '',
                    value: ('value' in el ? (el.value || '') : (el.innerText || '')),
                    parents: parentTexts,
                    x: rect.x, y: rect.y, w: rect.width, h: rect.height
                };
            }"""
        )
    except Exception:
        return {}


def _candidate_score(meta, kind):
    blob = " ".join([
        str(meta.get("placeholder", "")),
        str(meta.get("aria", "")),
        str(meta.get("name", "")),
        str(meta.get("id", "")),
        str(meta.get("cls", "")),
        " ".join(meta.get("parents", []) or []),
    ]).lower()

    score = 0.0
    tag = meta.get("tag", "")
    typ = (meta.get("type", "") or "").lower()
    inputmode = (meta.get("inputmode", "") or "").lower()
    maxlength = str(meta.get("maxlength", "") or "")

    if kind == "title":
        for kw, pts in [
            ("标题", 16), ("宝贝标题", 20), ("商品标题", 20), ("title", 8),
            ("卖点", 2)
        ]:
            if kw in blob:
                score += pts
        if "描述" in blob or "详情" in blob:
            score -= 14
        if "价格" in blob or "售价" in blob or "原价" in blob:
            score -= 12
        if tag == "input":
            score += 3
        if maxlength in {"30", "40", "50", "60"}:
            score += 4

    elif kind == "description":
        for kw, pts in [
            ("描述", 18), ("宝贝描述", 24), ("商品描述", 24), ("详情", 8), ("description", 8)
        ]:
            if kw in blob:
                score += pts
        if "标题" in blob:
            score -= 12
        if "价格" in blob:
            score -= 10
        if tag == "textarea":
            score += 5
        if meta.get("contenteditable") == "true":
            score += 3

    elif kind == "price":
        for kw, pts in [
            ("售价", 24), ("价格", 18), ("卖价", 20), ("想卖", 14),
            ("price", 8), ("¥", 3), ("￥", 3)
        ]:
            if kw in blob:
                score += pts
        if "原价" in blob:
            score -= 16
        if "标题" in blob or "描述" in blob:
            score -= 12
        if typ == "number":
            score += 7
        if inputmode in {"decimal", "numeric"}:
            score += 6
        if tag == "input":
            score += 2

    # 优先页面上方、尺寸正常的可编辑控件
    if meta.get("w", 0) >= 40 and meta.get("h", 0) >= 18:
        score += 1
    return score


def _set_editable_value(item, value):
    """兼容普通 input/textarea 和 contenteditable/React 控件。"""
    value = str(value)
    try:
        tag = (item.evaluate("el => (el.tagName || '').toLowerCase()") or "")
    except Exception:
        tag = ""

    if tag in ("input", "textarea"):
        try:
            item.fill(value, timeout=2500)
            return True
        except Exception:
            pass

        # React/Vue 受控输入框兜底：使用原生 setter 并派发 input/change。
        try:
            ok = item.evaluate(
                """(el, value) => {
                    const proto = el.tagName.toLowerCase() === 'textarea'
                      ? HTMLTextAreaElement.prototype
                      : HTMLInputElement.prototype;
                    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
                    if (desc && desc.set) desc.set.call(el, value);
                    else el.value = value;
                    el.dispatchEvent(new Event('input', {bubbles:true}));
                    el.dispatchEvent(new Event('change', {bubbles:true}));
                    el.dispatchEvent(new Event('blur', {bubbles:true}));
                    return true;
                }""",
                value
            )
            if ok:
                return True
        except Exception:
            pass

    # contenteditable 或特殊可编辑区域
    try:
        editable = item.get_attribute("contenteditable")
    except Exception:
        editable = None

    if editable == "true" or tag not in ("input", "textarea"):
        try:
            item.click(timeout=2000)
            item.press("Control+A")
            item.type(value, delay=8)
            return True
        except Exception:
            pass

        try:
            ok = item.evaluate(
                """(el, value) => {
                    el.focus();
                    el.innerText = value;
                    el.dispatchEvent(new InputEvent('input', {
                        bubbles:true, inputType:'insertText', data:value
                    }));
                    el.dispatchEvent(new Event('change', {bubbles:true}));
                    return true;
                }""",
                value
            )
            if ok:
                return True
        except Exception:
            pass

    return False


def _fill_smart(page, kind, value, selectors=None):
    """
    先使用明确 selector；失败后扫描当前页面所有可见可编辑控件，
    根据 placeholder / aria-label / 周边中文标签自适应定位。
    """
    if value is None or str(value).strip() == "":
        return False

    # 1. 明确 selector 优先
    for sel in selectors or []:
        try:
            loc = page.locator(sel)
            for i in range(min(loc.count(), 12)):
                item = loc.nth(i)
                if item.is_visible() and _set_editable_value(item, value):
                    return True
        except Exception:
            pass

    # 2. 标签关联定位：从“标题/价格”等文字附近找输入框
    labels = {
        "title": ["宝贝标题", "商品标题", "标题"],
        "description": ["宝贝描述", "商品描述", "描述"],
        "price": ["售价", "价格", "想卖"],
    }.get(kind, [])

    for label in labels:
        try:
            texts = page.get_by_text(label, exact=False)
            for i in range(min(texts.count(), 15)):
                node = texts.nth(i)
                if not node.is_visible():
                    continue
                # 从标签向上最多找4级父容器，在其中寻找编辑控件
                container = node
                for _ in range(4):
                    try:
                        container = container.locator("..")
                        editables = container.locator(
                            "input:visible, textarea:visible, [contenteditable='true']:visible"
                        )
                        if editables.count():
                            for j in range(min(editables.count(), 8)):
                                item = editables.nth(j)
                                meta = _element_meta(item)
                                if _candidate_score(meta, kind) >= 4 and _set_editable_value(item, value):
                                    return True
                    except Exception:
                        break
        except Exception:
            pass

    # 3. 全页面候选打分
    candidates = []
    try:
        loc = page.locator("input:visible, textarea:visible, [contenteditable='true']:visible")
        for i in range(min(loc.count(), 80)):
            item = loc.nth(i)
            meta = _element_meta(item)
            score = _candidate_score(meta, kind)
            if score > 0:
                candidates.append((score, float(meta.get("y", 999999) or 999999), i))
    except Exception:
        candidates = []

    # 分数高优先；同分时上方控件优先
    candidates.sort(key=lambda x: (-x[0], x[1]))

    for score, _, idx in candidates[:12]:
        # 价格和标题避免用非常弱的候选
        threshold = 3 if kind == "description" else 5
        if score < threshold:
            continue
        try:
            item = loc.nth(idx)
            if item.is_visible() and _set_editable_value(item, value):
                return True
        except Exception:
            pass

    return False


def _wait_for_manual_browser_close(ctx, preferred_page=None):
    """
    自动填充后绝不主动关闭浏览器。
    即使闲鱼在发布/上传过程中替换了标签页，也监控整个 browser context，
    只有用户主动把该浏览器所有页面都关掉，本次任务才结束。
    """
    while True:
        try:
            pages = [p for p in ctx.pages if not p.is_closed()]
        except Exception:
            break

        if not pages:
            break

        # 如果原页面被替换/关闭，不再把它当成任务结束。
        page = preferred_page if preferred_page in pages else pages[-1]
        try:
            page.wait_for_timeout(1000)
        except Exception:
            try:
                time.sleep(1)
            except Exception:
                break

def _is_publish_page(page) -> bool:
    try:
        url = (page.url or "").lower()
        if "/publish" in url:
            return True
    except Exception:
        pass

    # 页面特征兜底
    return (
        _visible_any(page, ["发布闲置", "宝贝描述", "价格"])
        and page.locator("input[type='file']").count() > 0
    )


def _save_failure(page, product_id, reason):
    folder = LOG_DIR / f"xianyu_{product_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    folder.mkdir(parents=True, exist_ok=True)

    try:
        page.screenshot(path=str(folder / "screenshot.png"), full_page=True)
    except Exception:
        pass

    try:
        (folder / "page.html").write_text(page.content(), encoding="utf-8")
    except Exception:
        pass

    try:
        (folder / "url.txt").write_text(page.url or "", encoding="utf-8")
    except Exception:
        pass

    (folder / "log.txt").write_text(reason, encoding="utf-8")
    return str(folder)


def _open_publish_page(page, ctx):
    """
    不再点击首页任何“发布”文字。
    直接进入官方网页发布地址，避免误点商品卡片/帖子。
    """
    _goto_with_restored_auth(page, ctx, XIANYU_PUBLISH_URL)

    if login_state(page, ctx) == "logged_in" and _is_publish_page(page):
        return True

    return False


def fill_xianyu(product, login_wait_sec=300):
    states = []
    pid = product.get("id", "unknown")

    with persistent_browser(PROFILE_XIANYU, False) as ctx:
        page = ctx.pages[0] if ctx.pages else ctx.new_page()

        try:
            # 关键修复：发布时先恢复持久化登录态，再直接打开 /publish。
            _goto_with_restored_auth(page, ctx, XIANYU_PUBLISH_URL)
            states.append("已直接打开闲鱼发布页")

            state = login_state(page, ctx)
            states.append("登录检测：" + login_evidence(page, ctx))

            if state != "logged_in":
                states.append("当前发布页未识别到有效登录状态，请在这个浏览器窗口完成登录。")
                states.append(f"程序等待登录，最长 {login_wait_sec} 秒。")

                result, _ = _wait_for_login(page, ctx, login_wait_sec)

                if result != "logged_in":
                    if result == "closed":
                        states.append("浏览器被关闭")
                        return {"ok": False, "states": states, "log_dir": ""}

                    states.append("登录等待超时")
                    folder = _save_failure(page, pid, "\n".join(states))
                    return {"ok": False, "states": states, "log_dir": folder}

                states.append("登录成功，正在保存并重新进入发布页...")
                _stabilize_and_save_login(page, ctx)

                # 登录流程可能把页面送回首页，所以强制重新打开 /publish。
                page.goto(XIANYU_PUBLISH_URL, wait_until="domcontentloaded", timeout=90000)
                page.wait_for_timeout(2000)

                if login_state(page, ctx) != "logged_in":
                    states.append("重新进入发布页后登录状态再次失效")
                    folder = _save_failure(page, pid, "\n".join(states))
                    return {"ok": False, "states": states, "log_dir": folder}

            else:
                states.append("已恢复并确认登录状态")

            # 无论登录完成后网站跳到哪里，都强制校准到 /publish。
            if not _is_publish_page(page):
                page.goto(XIANYU_PUBLISH_URL, wait_until="domcontentloaded", timeout=90000)
                page.wait_for_timeout(2200)

            if not _is_publish_page(page):
                states.append(f"未进入发布页，当前URL：{page.url}")
                folder = _save_failure(page, pid, "\n".join(states))
                return {"ok": False, "states": states, "log_dir": folder}

            states.append("已确认进入发布页面")

            title = product.get("ai_title") or product.get("source_title") or ""
            desc = product.get("description") or ""
            price = product.get("sale_price") or ""
            images = [p for p in product.get("images", []) if Path(p).exists()]

            uploaded = False
            try:
                files = page.locator("input[type='file']")
                for i in range(min(files.count(), 10)):
                    inp = files.nth(i)
                    try:
                        # 按需求：默认仅上传图片管理列表中的前6张。
                        inp.set_input_files(images[:6])
                        uploaded = True
                        break
                    except Exception:
                        pass
            except Exception:
                pass
            states.append(
                f"图片已上传（{min(len(images), 6)} 张）"
                if uploaded else "图片上传控件未成功使用"
            )

            # 标题：优先 AI 标题，没有则使用采集原始标题
            a = _fill_smart(page, "title", title[:50], TITLE_SELECTORS)
            states.append("标题已填" if a else "标题自动定位失败，请在发布页手动补充")

            # 描述
            b = _fill_smart(page, "description", desc, DESC_SELECTORS)
            states.append("描述已填" if b else "描述自动定位失败，请在发布页手动补充")

            # 售价：传纯数字，避免部分前端控件拒绝“48.00”一类格式
            price_value = price
            try:
                price_value = f"{float(price):g}"
            except Exception:
                pass
            c = _fill_smart(page, "price", price_value, PRICE_SELECTORS)
            states.append("价格已填" if c else "价格自动定位失败，请在发布页手动补充")

            # 不管自动定位是否全部成功，都绝不因为“某字段未填”而关闭页面。
            # 自动填充只是辅助；剩余字段全部交给用户在当前发布页手动审阅处理。
            missing = []
            if not a: missing.append("标题")
            if not b: missing.append("描述")
            if not c: missing.append("价格")

            diag_dir = ""
            if missing:
                states.append("以下字段需要手动检查：" + "、".join(missing))
                try:
                    diag_dir = _save_failure(
                        page,
                        pid,
                        "\n".join(states) + "\n说明：本次为部分自动填充，浏览器保持打开供人工完成。"
                    )
                    states.append("已保存当前页面诊断快照，但不会关闭发布页。")
                except Exception:
                    pass

            # 再保存一次当前已登录状态，降低下次丢失概率。
            _save_auth_state(ctx)

            states.append("自动导入阶段结束。现在请直接在闲鱼页面手动审阅、修改并决定是否发布。")
            states.append("程序不会设置倒计时，也不会主动关闭闲鱼浏览器。")
            try:
                page.bring_to_front()
            except Exception:
                pass

            # 关键修复：
            # 之前只监控原 page；闲鱼可能在上传/路由切换时替换或关闭该 tab，
            # 导致程序误以为用户关掉页面，随后 context manager 把整个浏览器关闭。
            # 现在监控整个 context，直到用户主动关闭整个浏览器。
            _wait_for_manual_browser_close(ctx, page)

            return {
                "ok": True,
                "partial": bool(missing),
                "states": states + ["检测到你已手动关闭闲鱼浏览器，本次任务结束。"],
                "log_dir": diag_dir
            }

        except Exception as e:
            try:
                if page.is_closed():
                    return {
                        "ok": False,
                        "states": states + ["浏览器被关闭，任务已停止。"],
                        "log_dir": "",
                    }
            except Exception:
                pass

            folder = _save_failure(page, pid, repr(e) + "\n" + "\n".join(states))
            return {
                "ok": False,
                "states": states + [f"异常：{e}"],
                "log_dir": folder,
            }
