from __future__ import annotations
import os, sys
from pathlib import Path
from dotenv import load_dotenv

APP_NAME = "1688XianyuAssistant"
DATA_APP_NAME = "1688XianyuAssistantV5"
APP_VERSION = "5.0.3"

def code_root() -> Path:
    # 用户可编辑配置目录：EXE旁边 / 源码项目根目录
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[1]

def resource_root() -> Path:
    # PyInstaller onefile 会把内置资源释放到 sys._MEIPASS
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)
    return Path(__file__).resolve().parents[1]

CODE_ROOT = code_root()
RESOURCE_ROOT = resource_root()
load_dotenv(CODE_ROOT / ".env")

LOCAL_APPDATA = Path(os.getenv("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
# V5 intentionally uses a new, isolated data directory.  It never opens or
# migrates the V4 database under %LOCALAPPDATA%\1688XianyuAssistant.
DATA_ROOT = LOCAL_APPDATA / DATA_APP_NAME
LEGACY_DATA_ROOT = LOCAL_APPDATA / APP_NAME
LEGACY_DB_PATH = LEGACY_DATA_ROOT / "database" / "products.db"

DB_DIR = DATA_ROOT / "database"
IMAGE_DIR = DATA_ROOT / "images"
PROFILE_DIR = DATA_ROOT / "profiles"
PROFILE_1688 = PROFILE_DIR / "1688"
PROFILE_XIANYU = PROFILE_DIR / "xianyu"
PROFILE_FISHSHOP = PROFILE_DIR / "fishshop"
LOG_DIR = DATA_ROOT / "logs"
BACKUP_DIR = DATA_ROOT / "backups"
CONFIG_DIR = DATA_ROOT / "config"

for p in [DATA_ROOT, DB_DIR, IMAGE_DIR, PROFILE_1688, PROFILE_XIANYU, PROFILE_FISHSHOP, LOG_DIR, BACKUP_DIR, CONFIG_DIR]:
    p.mkdir(parents=True, exist_ok=True)

DB_PATH = DB_DIR / "products.db"

AI_PROVIDER = os.getenv("AI_PROVIDER", "auto").strip().lower() or "auto"
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434").rstrip("/")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "qwen3:8b").strip() or "qwen3:8b"
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5.2").strip()
BROWSER_HEADLESS = os.getenv("BROWSER_HEADLESS", "false").lower() in {"1","true","yes","on"}
XIANYU_HOME_URL = os.getenv("XIANYU_HOME_URL", "https://www.goofish.com/").strip()
XIANYU_PUBLISH_URL = os.getenv("XIANYU_PUBLISH_URL", "https://www.goofish.com/publish").strip()
XIANYU_AUTH_STATE = CONFIG_DIR / "xianyu_auth_state.json"
FISHSHOP_PUBLISH_URL = os.getenv(
    "FISHSHOP_PUBLISH_URL",
    "https://seller.goofish.com/?site=COMMONPRO#/seller-item/publish",
).strip()
FISHSHOP_AUTH_STATE = CONFIG_DIR / "fishshop_auth_state.json"
APP_STATE_PATH = CONFIG_DIR / "app_state.json"
