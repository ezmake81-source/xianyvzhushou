from __future__ import annotations
import shutil,zipfile
from datetime import datetime
from pathlib import Path
from .config import DATA_ROOT,BACKUP_DIR

def create_backup():
    BACKUP_DIR.mkdir(parents=True,exist_ok=True)
    out=BACKUP_DIR/f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
    with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as z:
        for sub in ["database","images","config"]:
            base=DATA_ROOT/sub
            if base.exists():
                for p in base.rglob("*"):
                    if p.is_file():z.write(p,p.relative_to(DATA_ROOT))
    return out
