from __future__ import annotations


def format_attributes(attrs) -> str:
    if not isinstance(attrs, dict):
        return ""
    lines = []
    for key, value in attrs.items():
        key = str(key).strip()
        if isinstance(value, (list, tuple)):
            value = "、".join(str(x).strip() for x in value if str(x).strip())
        elif isinstance(value, dict):
            value = "、".join(f"{k}:{v}" for k, v in value.items())
        value = str(value).strip()
        if key and value and value.lower() not in {"none", "null", "未知", "--"}:
            lines.append(f"{key}：{value}")
    return "\n".join(lines)


def description_with_attributes(description: str, attrs, enabled: bool = True) -> str:
    description = (description or "").strip()
    block = format_attributes(attrs) if enabled else ""
    if not block:
        return description
    marker = "【商品属性】"
    if marker in description:
        description = description.split(marker, 1)[0].rstrip()
    return f"{description}\n\n{marker}\n{block}".strip()
