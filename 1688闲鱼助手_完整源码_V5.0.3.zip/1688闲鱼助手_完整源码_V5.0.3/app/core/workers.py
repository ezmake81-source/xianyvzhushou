from PySide6.QtCore import QThread,Signal

class JobThread(QThread):
    ok=Signal(object); fail=Signal(str)
    def __init__(self,fn,*args,**kwargs):
        super().__init__();self.fn=fn;self.args=args;self.kwargs=kwargs
    def run(self):
        try:self.ok.emit(self.fn(*self.args,**self.kwargs))
        except Exception:
            import traceback;self.fail.emit(traceback.format_exc())
