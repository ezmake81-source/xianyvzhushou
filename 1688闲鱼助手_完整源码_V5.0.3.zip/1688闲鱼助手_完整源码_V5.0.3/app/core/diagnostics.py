from __future__ import annotations
import shutil,sqlite3,requests
from pathlib import Path
from .config import DB_PATH,IMAGE_DIR,LOG_DIR,PROFILE_1688,PROFILE_XIANYU,PROFILE_FISHSHOP,DATA_ROOT,OLLAMA_BASE_URL

def run_checks():
    checks=[]
    checks.append(("数据目录",DATA_ROOT.exists(),str(DATA_ROOT)))
    checks.append(("数据库",DB_PATH.exists(),"已创建" if DB_PATH.exists() else "未创建"))
    checks.append(("图片目录",IMAGE_DIR.exists(),str(IMAGE_DIR)))
    checks.append(("日志目录",LOG_DIR.exists(),str(LOG_DIR)))
    free=shutil.disk_usage(DATA_ROOT).free/1024**3
    checks.append(("磁盘剩余",free>10,f"{free:.1f} GB"))
    try:
        with sqlite3.connect(DB_PATH) as c:c.execute("SELECT 1")
        checks.append(("SQLite",True,"正常"))
    except Exception as e:checks.append(("SQLite",False,str(e)))
    try:
        ok=requests.get(f"{OLLAMA_BASE_URL}/api/tags",timeout=1.2).status_code==200
        checks.append(("Ollama",ok,"已连接" if ok else "未连接"))
    except:checks.append(("Ollama",False,"未连接"))
    checks.append(("1688登录配置",PROFILE_1688.exists(),"存在浏览器配置"))
    checks.append(("闲鱼登录配置",PROFILE_XIANYU.exists(),"存在浏览器配置"))
    checks.append(("鱼小铺登录配置",PROFILE_FISHSHOP.exists(),"存在独立浏览器配置"))
    return checks
