from __future__ import annotations

import json
import shutil
import sqlite3
from pathlib import Path

from . import db
from .config import IMAGE_DIR


JSON_FIELDS = {
    "sku_json": ("sku", []),
    "attrs_json": ("attrs", {}),
    "images_json": ("images", []),
    "image_types_json": ("image_types", {}),
    "posts_json": ("posts", []),
}


def _json(value, default):
    try:
        return json.loads(value or "")
    except Exception:
        return default


def _copy_images(paths, source_db: Path, legacy_id: int):
    copied = 0
    result = []
    folder = IMAGE_DIR / "v4_import"
    for index, raw in enumerate(paths or []):
        source = Path(str(raw))
        candidates = [source]
        if not source.is_absolute():
            candidates += [source_db.parent.parent / source, source_db.parent / source]
        existing = next((p for p in candidates if p.is_file()), None)
        if not existing:
            result.append(str(raw))
            continue
        folder.mkdir(parents=True, exist_ok=True)
        safe_name = existing.name or f"image_{index}.jpg"
        target = folder / f"{legacy_id}_{index}_{safe_name}"
        if not target.exists():
            shutil.copy2(existing, target)
            copied += 1
        result.append(str(target))
    return result, copied


def import_v4_database(source_path: str | Path):
    """Copy V4 products into V5 without ever opening the source for writing."""
    source = Path(source_path).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f"未找到 V4 数据库：{source}")
    source_key = str(source).casefold()
    uri = source.as_uri() + "?mode=ro"
    imported = skipped = failed = copied_images = 0
    errors = []
    with sqlite3.connect(uri, uri=True) as old:
        old.row_factory = sqlite3.Row
        if not old.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='products'"
        ).fetchone():
            raise ValueError("选择的文件不是有效的 V4 商品数据库。")
        rows = old.execute("SELECT * FROM products ORDER BY id").fetchall()

    for row in rows:
        legacy = dict(row)
        legacy_id = int(legacy.get("id") or 0)
        with db.conn() as current:
            if current.execute(
                "SELECT 1 FROM legacy_imports WHERE source_db=? AND legacy_id=?",
                (source_key, legacy_id),
            ).fetchone():
                skipped += 1
                continue
        try:
            data = dict(legacy)
            for old_name, (new_name, default) in JSON_FIELDS.items():
                data[new_name] = _json(legacy.get(old_name), default)
            data["images"], count = _copy_images(data["images"], source, legacy_id)
            copied_images += count
            product_id = db.create_product(data)
            with db.conn() as current:
                current.execute(
                    "UPDATE products SET created_at=?,updated_at=? WHERE id=?",
                    (
                        legacy.get("created_at") or db._now(),
                        legacy.get("updated_at") or db._now(),
                        product_id,
                    ),
                )
                current.execute(
                    "INSERT INTO legacy_imports(source_db,legacy_id,product_id,imported_at) VALUES(?,?,?,?)",
                    (source_key, legacy_id, product_id, db._now()),
                )
            imported += 1
        except Exception as exc:
            failed += 1
            errors.append(f"V4 ID {legacy_id}: {exc}")
    return {
        "source": str(source),
        "total": len(rows),
        "imported": imported,
        "skipped": skipped,
        "failed": failed,
        "copied_images": copied_images,
        "errors": errors,
    }
