from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

from .config import CONFIG_DIR

SETTINGS_FILE = CONFIG_DIR / "ollama_settings.json"


def default_model_dir() -> Path:
    # 优先 D 盘；没有 D 盘时再回退到用户目录。
    if os.name == "nt" and Path("D:/").exists():
        return Path("D:/AI/OllamaModels")
    return Path.home() / ".ollama" / "models"


def current_model_dir() -> Path:
    env = os.environ.get("OLLAMA_MODELS", "").strip()
    if env:
        return Path(env)
    return default_model_dir()


def set_model_dir(path: str | Path) -> tuple[bool, str]:
    path = Path(path).expanduser().resolve()
    try:
        path.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return False, f"无法创建目录：{e}"

    if os.name != "nt":
        os.environ["OLLAMA_MODELS"] = str(path)
        return True, f"当前会话已设置为：{path}"

    try:
        p = subprocess.run(
            ["setx", "OLLAMA_MODELS", str(path)],
            capture_output=True,
            text=True,
            timeout=20,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if p.returncode != 0:
            msg = (p.stderr or p.stdout or "").strip()
            return False, f"写入 Windows 环境变量失败：{msg}"
        os.environ["OLLAMA_MODELS"] = str(path)
        return True, f"模型目录已设置为：{path}"
    except Exception as e:
        return False, f"设置失败：{e}"


def open_model_dir(path: str | Path | None = None) -> tuple[bool, str]:
    path = Path(path or current_model_dir())
    try:
        path.mkdir(parents=True, exist_ok=True)
        if os.name == "nt":
            os.startfile(str(path))
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
        return True, str(path)
    except Exception as e:
        return False, str(e)


def restart_ollama() -> tuple[bool, str]:
    """
    尝试重启 Ollama 后台进程，让新的 OLLAMA_MODELS 生效。
    不保证所有安装方式都完全相同，因此失败时只返回提示，不影响主程序。
    """
    if os.name != "nt":
        return False, "当前自动重启仅针对 Windows。"

    try:
        subprocess.run(
            ["taskkill", "/F", "/IM", "ollama.exe"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=10,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except Exception:
        pass

    exe = shutil.which("ollama")
    if not exe:
        # 常见安装位置兜底
        candidates = [
            Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Ollama" / "ollama.exe",
            Path("C:/Program Files/Ollama/ollama.exe"),
            Path("D:/AI/Ollama/ollama.exe"),
        ]
        for c in candidates:
            if c.exists():
                exe = str(c)
                break

    if not exe:
        return False, "未找到 ollama.exe。请手动退出并重新启动 Ollama。"

    try:
        flags = 0
        if os.name == "nt":
            flags = (
                getattr(subprocess, "DETACHED_PROCESS", 0)
                | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                | getattr(subprocess, "CREATE_NO_WINDOW", 0)
            )
        subprocess.Popen(
            [exe, "serve"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            creationflags=flags,
            close_fds=True,
        )
        return True, "Ollama 已尝试重启。新的模型目录应已生效。"
    except Exception as e:
        return False, f"自动重启失败：{e}\n请手动退出并重新启动 Ollama。"


def model_dir_info() -> dict:
    path = current_model_dir()
    exists = path.exists()
    try:
        usage = shutil.disk_usage(path if exists else path.parent)
        free_gb = usage.free / 1024**3
    except Exception:
        free_gb = 0.0

    return {
        "path": str(path),
        "exists": exists,
        "free_gb": round(free_gb, 1),
        "env_value": os.environ.get("OLLAMA_MODELS", ""),
    }
