from __future__ import annotations
import hashlib, json, mimetypes, re, time
from pathlib import Path
from urllib.parse import urlparse
import requests
from .browser import persistent_browser
from .config import PROFILE_1688, IMAGE_DIR

OFFER_RE=re.compile(r"/offer/(\d+)\.html")

def offer_id_from_url(url):
    m=OFFER_RE.search(url or "")
    return m.group(1) if m else ""

def _clean_url(u):
    if not u:return ""
    u=u.replace("\\u002F","/").replace("\\/","/").replace("&amp;","&").strip()
    if u.startswith("//"):u="https:"+u
    return u

def _extract_json_candidates(html):
    out=[]
    for pat in [
        r'window\.__INIT_DATA__\s*=\s*({.*?})\s*;</script>',
        r'window\.__INITIAL_STATE__\s*=\s*({.*?})\s*;</script>',
        r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
    ]:
        for m in re.finditer(pat,html,re.S|re.I):
            txt=m.group(1).strip()
            try: out.append(json.loads(txt))
            except Exception: pass
    return out

def _walk(obj):
    if isinstance(obj,dict):
        for k,v in obj.items():
            yield k,v
            yield from _walk(v)
    elif isinstance(obj,list):
        for v in obj: yield from _walk(v)

def _number(value):
    if isinstance(value, (int, float)):
        return float(value) if 0 <= float(value) < 1000000 else None
    m=re.search(r"(?<!\d)(\d+(?:\.\d{1,4})?)(?!\d)",str(value or "").replace(",",""))
    if not m:return None
    x=float(m.group(1)); return x if 0 <= x < 1000000 else None

def _pairs(value):
    """Read common 1688 [{name,value}] / property structures."""
    out={}
    if isinstance(value,dict):
        for k,v in value.items():
            if isinstance(v,(str,int,float,bool)) and 0<len(str(k))<40 and len(str(v))<300:
                out[str(k).strip()]=str(v).strip()
    elif isinstance(value,list):
        for item in value:
            if not isinstance(item,dict):continue
            name=next((item.get(k) for k in ("name","attributeName","propertyName","propName","key") if item.get(k)),None)
            val=next((item.get(k) for k in ("value","attributeValue","propertyValue","valueName","text") if item.get(k) is not None),None)
            if name and val is not None:
                if isinstance(val,list):val="、".join(str(x.get("name",x)) if isinstance(x,dict) else str(x) for x in val)
                out[str(name).strip()]=str(val).strip()
    return {k:v for k,v in out.items() if k and v}

def _tier_rows(value):
    rows=[]
    seq=value if isinstance(value,list) else [value]
    for item in seq:
        if not isinstance(item,dict):continue
        price=next((_number(item.get(k)) for k in ("price","unitPrice","promotionPrice","discountPrice") if _number(item.get(k)) is not None),None)
        qty=next((_number(item.get(k)) for k in ("beginAmount","startQuantity","minQuantity","amount","quantity") if _number(item.get(k)) is not None),None)
        if price and price>0:rows.append({"min_qty":int(qty or 1),"price":round(price,4)})
    return rows

def _sku_rows(value):
    rows=[]
    items=value.items() if isinstance(value,dict) else enumerate(value) if isinstance(value,list) else []
    for key,item in items:
        if not isinstance(item,dict):continue
        price=next((_number(item.get(k)) for k in ("discountPrice","promotionPrice","price","salePrice") if _number(item.get(k)) is not None),None)
        stock=next((item.get(k) for k in ("canBookCount","stock","amountOnSale","inventory") if item.get(k) is not None),"")
        name=next((item.get(k) for k in ("name","specName","skuName","value") if item.get(k)),str(key))
        image=next((item.get(k) for k in ("imageUrl","image","picUrl") if item.get(k)),"")
        if price is not None or stock not in ("",None):
            rows.append({"name":str(name),"price":price or 0,"stock":str(stock),"image":_clean_url(str(image))})
    return rows

def _best_structured(data_list):
    result={"title":"","shop_name":"","price":0.0,"stock":"","min_order":"","sku":[],"attrs":{},
            "attrs_meta":{},"price_tiers":[],"one_piece_price":None,"shipping_cost":None,"shipping_cost_unknown":True}
    title_keys={"title","subject","offerTitle","productTitle","name"}
    shop_keys={"shopName","sellerName","companyName"}
    price_keys={"offerPrice","currentPrice","promotionPrice","discountPrice","priceText"}
    tier_keys={"priceRange","priceRanges","priceRangeList","ladderPrice","ladderPrices","priceModel"}
    sku_keys={"skuMap","skuList","skuInfos","skuInfoMap","skuPriceList"}
    attr_keys={"attributes","attributeList","productAttributes","productProps","props","offerAttributes"}
    shipping_keys={"freight","freightFee","postFee","shippingFee","deliveryFee","logisticsFee"}
    for data in data_list:
        for k,v in _walk(data):
            if not result["title"] and k in title_keys and isinstance(v,str) and len(v.strip())>4:
                result["title"]=v.strip()
            if not result["shop_name"] and k in shop_keys and isinstance(v,str):
                result["shop_name"]=v.strip()
            if k in tier_keys and not result["price_tiers"]:
                result["price_tiers"]=_tier_rows(v)
            if k in sku_keys and not result["sku"]:
                result["sku"]=_sku_rows(v)
            if k in attr_keys:
                result["attrs"].update(_pairs(v))
            if k in shipping_keys and result["shipping_cost"] is None:
                n=_number(v)
                if n is not None:
                    result["shipping_cost"]=n;result["shipping_cost_unknown"]=False
            if k in {"freeShipping","isFreeShipping","freePostage"} and v in (True,1,"true","1"):
                result["shipping_cost"]=0.0;result["shipping_cost_unknown"]=False
            if k in {"onePiecePrice","distributionPrice","dropshipPrice","consignPrice"} and result["one_piece_price"] is None:
                result["one_piece_price"]=_number(v)
            if k in price_keys and not result["price"]:
                x=_number(v)
                if x and 0<x<100000: result["price"]=x
    result["price_tiers"]=sorted({(x["min_qty"],x["price"]) for x in result["price_tiers"]})
    result["price_tiers"]=[{"min_qty":q,"price":p} for q,p in result["price_tiers"]]
    if result["price_tiers"]:
        result["price"]=result["price_tiers"][0]["price"]
        result["min_order"]=str(result["price_tiers"][0]["min_qty"])
    if result["one_piece_price"]:
        result["price"]=result["one_piece_price"]
    result["attrs_meta"]={k:{"source":"1688结构化数据","confidence":"high"} for k in result["attrs"]}
    return result

def _shipping_from_dom(page):
    try:text=page.locator("body").inner_text(timeout=3000)
    except Exception:return None,True
    for pat in (r"(?:运费|物流费|配送费)\s*[：:]?\s*[¥￥]?\s*(\d+(?:\.\d{1,2})?)",):
        m=re.search(pat,text)
        if m:return float(m.group(1)),False
    if re.search(r"(?:运费|物流)[^\n]{0,20}(?:包邮|免运费)",text):return 0.0,False
    return None,True

def _attrs_from_dom(page):
    out={}
    try:
        rows=page.locator("[class*='attribute'] li, [class*='attribute'] tr, [class*='property'] li, [class*='property'] tr")
        for i in range(min(rows.count(),120)):
            t=re.sub(r"\s+"," ",rows.nth(i).inner_text(timeout=500)).strip()
            parts=re.split(r"[：:]",t,maxsplit=1)
            if len(parts)==2 and 0<len(parts[0])<40 and 0<len(parts[1])<300:out[parts[0].strip()]=parts[1].strip()
    except Exception:pass
    return out

def _text(page, selectors):
    for sel in selectors:
        try:
            loc=page.locator(sel).first
            if loc.count() and loc.is_visible():
                t=loc.inner_text(timeout=1200).strip()
                if t:return t
        except Exception: pass
    return ""

def _price_from_text(t):
    vals=[]
    for n in re.findall(r"(?<!\d)(\d+(?:\.\d{1,2})?)(?!\d)",(t or "").replace(",","")):
        try:
            v=float(n)
            if 0<v<100000:vals.append(v)
        except: pass
    return min(vals) if vals else 0.0

def _image_score(url):
    u=url.lower()
    s=0
    if any(x in u for x in ["alicdn","detail","offer","sku"]): s+=3
    if any(x in u for x in ["logo","avatar","icon","sprite","qr","80x80","60x60","100x100"]): s-=10
    return s

def _collect_images(page):
    urls=set()
    for _ in range(10):
        try:
            page.mouse.wheel(0,900)
            page.wait_for_timeout(250)
        except: pass
    try:
        imgs=page.locator("img")
        for i in range(min(imgs.count(),700)):
            el=imgs.nth(i)
            for attr in ("src","data-src","data-lazyload-src","data-original","srcset"):
                try:v=el.get_attribute(attr) or ""
                except:v=""
                if not v:continue
                if attr=="srcset":
                    for p in v.split(","):urls.add(_clean_url(p.strip().split(" ")[0]))
                else:urls.add(_clean_url(v))
    except: pass
    try:
        html=page.content()
        for u in re.findall(r'https?://[^"\'\s<>]+?\.(?:jpg|jpeg|png|webp)(?:\?[^"\'\s<>]*)?',html,re.I):
            urls.add(_clean_url(u))
    except: pass
    return sorted([u for u in urls if u.startswith("http") and _image_score(u)>-4], key=_image_score, reverse=True)[:160]

def _guess_ext(url,ct=""):
    p=urlparse(url).path.lower()
    for e in (".jpg",".jpeg",".png",".webp"):
        if p.endswith(e):return ".jpg" if e==".jpeg" else e
    return mimetypes.guess_extension(ct.split(";")[0].strip()) or ".jpg"

def _download(urls,offer_id,maxn=24):
    target=IMAGE_DIR/(offer_id or "unknown")
    target.mkdir(parents=True,exist_ok=True)
    sess=requests.Session()
    sess.headers.update({"User-Agent":"Mozilla/5.0","Referer":"https://detail.1688.com/"})
    saved=[]; seen=set()
    for u in urls:
        if len(saved)>=maxn:break
        try:
            r=sess.get(u,timeout=15)
            if r.status_code!=200 or len(r.content)<12000:continue
            h=hashlib.sha1(r.content).hexdigest()
            if h in seen:continue
            seen.add(h)
            p=target/f"{len(saved)+1:02d}_{h[:8]}{_guess_ext(u,r.headers.get('content-type',''))}"
            p.write_bytes(r.content); saved.append(str(p))
        except:pass
    return saved

def scrape_1688(url):
    oid=offer_id_from_url(url)
    with persistent_browser(PROFILE_1688,False) as ctx:
        page=ctx.pages[0] if ctx.pages else ctx.new_page()
        page.goto(url,wait_until="domcontentloaded",timeout=90000)
        page.wait_for_timeout(2500)
        html=page.content()
        structured=_best_structured(_extract_json_candidates(html))
        dom_attrs=_attrs_from_dom(page)
        for k,v in dom_attrs.items():
            structured["attrs"].setdefault(k,v)
            structured["attrs_meta"].setdefault(k,{"source":"1688页面","confidence":"medium"})
        if structured["shipping_cost_unknown"]:
            structured["shipping_cost"],structured["shipping_cost_unknown"]=_shipping_from_dom(page)

        title=structured["title"]
        if not title:
            title=_text(page,[
                "[data-testid='offer-title']",
                "[class*='offer-title']",
                "[class*='product-title']",
                "h1"
            ])
        shop=structured["shop_name"] or _text(page,[
            "[class*='company']","[class*='shop-name']","[class*='seller']"
        ])
        # 避免误把公司名当商品名
        if title and shop and title.strip()==shop.strip():
            title=""
        if not title:
            try:
                pt=page.title().strip()
                title=re.sub(r"[-_丨|].*$","",pt).strip()
            except:title=""

        price=structured["price"]
        if not price:
            price=_price_from_text(_text(page,[
                "[class*='price']","[class*='Price']","[data-testid*='price']"
            ]))
        images=_download(_collect_images(page),oid)
        return {
            "source_url":url,"offer_id":oid,"source_title":title[:300],"shop_name":shop[:200],
            "cost":price,"stock":structured["stock"],"min_order":structured["min_order"],
            "sku":structured["sku"],"attrs":structured["attrs"],"attrs_meta":structured["attrs_meta"],
            "price_tiers":structured["price_tiers"],"one_piece_price":structured["one_piece_price"],
            "shipping_cost":structured["shipping_cost"],"shipping_cost_unknown":structured["shipping_cost_unknown"],
            "images":images,
            "image_types":{"main":images[:6],"sku":[],"detail":images[6:]},
            "status":"已采集"
        }
