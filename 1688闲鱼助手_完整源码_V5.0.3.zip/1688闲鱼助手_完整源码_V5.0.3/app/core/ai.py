from __future__ import annotations
import json,re,requests
from .config import AI_PROVIDER,OLLAMA_BASE_URL,OLLAMA_MODEL,OPENAI_API_KEY,OPENAI_MODEL
from .description import description_with_attributes

def ollama_available(timeout=1.5):
    try:return requests.get(f"{OLLAMA_BASE_URL}/api/tags",timeout=timeout).status_code==200
    except:return False

def ollama_models():
    try:
        r=requests.get(f"{OLLAMA_BASE_URL}/api/tags",timeout=3)
        if r.status_code!=200:return []
        return [x.get("name","") for x in r.json().get("models",[]) if x.get("name")]
    except:return []

def _json(s):
    s=(s or "").strip()
    s=re.sub(r"^```(?:json)?\s*","",s,flags=re.I); s=re.sub(r"\s*```$","",s)
    try:
        x=json.loads(s); return x if isinstance(x,dict) else None
    except:pass
    a,b=s.find("{"),s.rfind("}")
    if 0<=a<b:
        try:
            x=json.loads(s[a:b+1]); return x if isinstance(x,dict) else None
        except:pass

def _prompt(product,instruction,style):
    payload={
      "source_title":product.get("source_title",""),
      "shop_name":product.get("shop_name",""),
      "attrs":product.get("attrs",{}),
      "sku":product.get("sku",[]),
      "cost":product.get("cost",0),
      "shipping_cost":product.get("shipping_cost"),
      "shipping_cost_unknown":product.get("shipping_cost_unknown",True),
      "price_tiers":product.get("price_tiers",[]),
      "style":style,"instruction":instruction
    }
    sys=("你是闲鱼商品文案助手。只能基于输入信息改写，不虚构品牌授权、材质、尺寸、库存、原价、功效、售后。"
         "默认避免跨境、厂家直销等不适合普通闲鱼卖家的措辞。"
         "严格输出JSON：title, description, posts, keywords。title尽量30字以内，posts固定5条。")
    return sys+"\n输入："+json.dumps(payload,ensure_ascii=False)

def _normalize(x,provider):
    posts=x.get("posts",[])
    if isinstance(posts,str):posts=[i.strip() for i in posts.splitlines() if i.strip()]
    kws=x.get("keywords",[])
    if isinstance(kws,str):kws=[i.strip() for i in re.split(r"[,，\s]+",kws) if i.strip()]
    return {
      "title":str(x.get("title","")).strip(),
      "description":str(x.get("description","")).strip(),
      "posts":[str(i).strip() for i in posts][:5],
      "keywords":[str(i).strip() for i in kws][:10],
      "provider":provider
    }

def generate_copy(product,instruction="",style="普通闲鱼卖家"):
    if AI_PROVIDER in {"auto","ollama"} and ollama_available():
        try:
            r=requests.post(f"{OLLAMA_BASE_URL}/api/generate",json={
              "model":OLLAMA_MODEL,"prompt":_prompt(product,instruction,style),
              "stream":False,"format":"json","options":{"temperature":0.65,"num_predict":1000}
            },timeout=180)
            r.raise_for_status()
            x=_json(r.json().get("response",""))
            if x:
                out=_normalize(x,f"ollama:{OLLAMA_MODEL}")
                out["description"]=description_with_attributes(out["description"],product.get("attrs",{}),product.get("append_attrs",True))
                return out
        except Exception:
            if AI_PROVIDER=="ollama":raise
    if AI_PROVIDER in {"auto","openai"} and OPENAI_API_KEY:
        from openai import OpenAI
        client=OpenAI(api_key=OPENAI_API_KEY)
        resp=client.responses.create(model=OPENAI_MODEL,input=_prompt(product,instruction,style))
        x=_json(getattr(resp,"output_text",""))
        if x:
            out=_normalize(x,f"openai:{OPENAI_MODEL}")
            out["description"]=description_with_attributes(out["description"],product.get("attrs",{}),product.get("append_attrs",True))
            return out
    title=(product.get("source_title") or "精选好物").replace("跨境","").replace("厂家直销","").strip()[:30]
    return {
      "title":title,
      "description":description_with_attributes(
          f"{title}\n\n商品信息以页面和实物为准，喜欢可以先聊聊。",
          product.get("attrs",{}),product.get("append_attrs",True)),
      "posts":[f"{title}，整体风格比较耐看。"]*5,
      "keywords":[],
      "provider":"template"
    }
