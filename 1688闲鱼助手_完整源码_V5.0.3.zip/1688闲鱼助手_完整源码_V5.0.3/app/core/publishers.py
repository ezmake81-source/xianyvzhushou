from __future__ import annotations

from abc import ABC, abstractmethod
from datetime import datetime
import json
from pathlib import Path
import time

from .browser import persistent_browser
from .config import (
    FISHSHOP_AUTH_STATE, FISHSHOP_PUBLISH_URL, LOG_DIR, PROFILE_FISHSHOP,
)
from .description import description_with_attributes
from .xianyu import (
    _fill_smart, _save_failure, _set_editable_value,
    _wait_for_manual_browser_close, fill_xianyu, login_state,
)


class PublisherBase(ABC):
    channel = ""

    @abstractmethod
    def login(self, timeout_sec=300): ...

    @abstractmethod
    def fill(self, product, login_wait_sec=300): ...


class NormalXianyuPublisher(PublisherBase):
    channel = "normal"

    def login(self, timeout_sec=300):
        from .xianyu import login_xianyu
        return login_xianyu(timeout_sec)

    def fill(self, product, login_wait_sec=300):
        return fill_xianyu(product, login_wait_sec)


def _save_state(ctx):
    try:
        FISHSHOP_AUTH_STATE.parent.mkdir(parents=True, exist_ok=True)
        ctx.storage_state(path=str(FISHSHOP_AUTH_STATE))
        return True
    except Exception:
        return False


def _restore_state(ctx):
    if not FISHSHOP_AUTH_STATE.exists(): return False
    try:
        data=json.loads(FISHSHOP_AUTH_STATE.read_text(encoding="utf-8"))
        if data.get("cookies"):ctx.add_cookies(data["cookies"])
        return True
    except Exception:return False


def _restore_local_storage(page):
    if not FISHSHOP_AUTH_STATE.exists():return False
    try:
        data=json.loads(FISHSHOP_AUTH_STATE.read_text(encoding="utf-8"));origin=page.evaluate("location.origin")
        for item in data.get("origins",[]):
            if item.get("origin")==origin:
                page.evaluate("items=>items.forEach(x=>localStorage.setItem(x.name,x.value))",item.get("localStorage",[]));return True
    except Exception:pass
    return False


def _seller_ready(page):
    try:
        url=(page.url or "").lower()
        return "seller.goofish.com" in url and (
            page.get_by_text("宝贝描述",exact=False).count()>0
            or page.get_by_text("商品规格",exact=False).count()>0
            or page.locator("input[type='file']").count()>0
        )
    except Exception:return False


def _goto_seller(page,ctx):
    restored=_restore_state(ctx)
    page.goto(FISHSHOP_PUBLISH_URL,wait_until="domcontentloaded",timeout=90000)
    page.wait_for_timeout(2200)
    if restored and _restore_local_storage(page):
        page.reload(wait_until="domcontentloaded",timeout=90000);page.wait_for_timeout(1500)


def _wait_ready(page, timeout_sec):
    end=time.time()+timeout_sec
    while time.time()<end:
        if page.is_closed():return False
        if _seller_ready(page):return True
        page.wait_for_timeout(1200)
    return False


def _click_text(page, text):
    try:
        loc=page.get_by_text(text,exact=False)
        for i in range(min(loc.count(),12)):
            if loc.nth(i).is_visible():loc.nth(i).click(timeout=1500);return True
    except Exception:pass
    return False


def _fill_near_label(page,label,value):
    if value in (None,""):return False
    try:
        labels=page.get_by_text(label,exact=False)
        for i in range(min(labels.count(),15)):
            if not labels.nth(i).is_visible():continue
            box=labels.nth(i)
            for _ in range(5):
                box=box.locator("..")
                edits=box.locator("input:visible,textarea:visible,[contenteditable='true']:visible")
                for j in range(min(edits.count(),15)):
                    if _set_editable_value(edits.nth(j),str(value)):return True
    except Exception:pass
    return False


def _upload_media(page, images, video=""):
    image_ok=video_ok=False
    try:
        inputs=page.locator("input[type='file']")
        for i in range(min(inputs.count(),20)):
            inp=inputs.nth(i);accept=(inp.get_attribute("accept") or "").lower()
            try:
                if video and "video" in accept and Path(video).exists():
                    inp.set_input_files(video);video_ok=True
                elif images and ("image" in accept or "video" not in accept) and not image_ok:
                    inp.set_input_files(images[:9]);image_ok=True
            except Exception:pass
    except Exception:pass
    return image_ok,video_ok


def _fill_skus(page, sku_rows):
    if not sku_rows:return True,"未配置SKU"
    _click_text(page,"添加规格类型")
    page.wait_for_timeout(500)
    names=[str(x.get("name","")).strip() for x in sku_rows if str(x.get("name","")).strip()]
    # The seller page changes frequently. Populate visible empty spec editors first,
    # then match generated table rows by their text for price/stock.
    try:
        edits=page.locator("input:visible")
        empty=[]
        for i in range(min(edits.count(),100)):
            e=edits.nth(i);ph=(e.get_attribute("placeholder") or "")
            if any(k in ph for k in ("规格值","规格名称","颜色","尺寸")):empty.append(e)
        for e,value in zip(empty,names):_set_editable_value(e,value)
    except Exception:pass
    filled=0
    for row in sku_rows:
        name=str(row.get("name","")).strip()
        try:
            node=page.get_by_text(name,exact=False).first
            box=node.locator("xpath=ancestor::tr[1]")
            if not box.count():box=node.locator("..").locator("..")
            edits=box.locator("input:visible")
            vals=[row.get("price",""),row.get("original_price",""),row.get("stock","")]
            for edit,val in zip([edits.nth(i) for i in range(min(edits.count(),3))],vals):
                if val not in (None,""):_set_editable_value(edit,val)
            filled+=1
        except Exception:pass
    return filled==len(sku_rows),f"SKU表格已匹配 {filled}/{len(sku_rows)} 行"


class FishShopPublisher(PublisherBase):
    channel = "fishshop"

    def login(self, timeout_sec=300):
        states=[]
        with persistent_browser(PROFILE_FISHSHOP,False) as ctx:
            page=ctx.pages[0] if ctx.pages else ctx.new_page()
            _goto_seller(page,ctx);states.append("已打开鱼小铺发布后台")
            if not _seller_ready(page):
                states.append("请在独立的鱼小铺浏览器窗口完成登录")
                if not _wait_ready(page,timeout_sec):
                    return {"ok":False,"states":states+["等待登录超时或浏览器已关闭"]}
            saved=_save_state(ctx)
            states.append("鱼小铺登录状态已保存" if saved else "浏览器Profile已保存")
            return {"ok":True,"states":states}

    def fill(self, product, login_wait_sec=300):
        states=[];pid=product.get("id","unknown")
        with persistent_browser(PROFILE_FISHSHOP,False) as ctx:
            page=ctx.pages[0] if ctx.pages else ctx.new_page()
            try:
                _goto_seller(page,ctx);states.append("已打开鱼小铺独立发布通道")
                if not _seller_ready(page):
                    states.append("请先完成鱼小铺登录")
                    if not _wait_ready(page,login_wait_sec):
                        folder=_save_failure(page,f"fishshop_{pid}","\n".join(states))
                        return {"ok":False,"states":states+["登录等待超时"],"log_dir":folder}
                    page.goto(FISHSHOP_PUBLISH_URL,wait_until="domcontentloaded",timeout=90000)
                    page.wait_for_timeout(1800)
                images=[p for p in product.get("images",[]) if Path(p).exists()]
                image_ok,video_ok=_upload_media(page,images,product.get("video_path", ""))
                states.append(f"宝贝图片已导入（{min(len(images),9)} 张）" if image_ok else "宝贝图片需手动检查")
                if product.get("video_path"):states.append("宝贝视频已导入" if video_ok else "宝贝视频需手动上传")
                desc=description_with_attributes(product.get("description", ""),product.get("attrs",{}),product.get("append_attrs",True))
                desc_ok=_fill_smart(page,"description",desc,["textarea[placeholder*='描述']","[contenteditable='true']"])
                states.append("宝贝描述已填" if desc_ok else "宝贝描述需手动检查")
                for key,value in (product.get("attrs") or {}).items():
                    _fill_near_label(page,str(key),value)
                price_ok=_fill_smart(page,"price",f"{float(product.get('sale_price',0)):g}",["input[placeholder*='价格']","input[placeholder*='售价']"])
                original=product.get("original_price",0)
                original_ok=not original or _fill_near_label(page,"原价",f"{float(original):g}")
                stock=product.get("stock","")
                stock_ok=not stock or _fill_near_label(page,"库存",stock)
                states.extend(["价格已填" if price_ok else "价格需手动检查",
                               "原价已填" if original_ok else "原价需手动检查",
                               "库存已填" if stock_ok else "库存需手动检查"])
                sku_ok,sku_state=_fill_skus(page,product.get("sku",[]));states.append(sku_state)
                modes={"free":"包邮","distance":"按距离计费","fixed":"一口价","template":"运费模板","none":"无需邮寄"}
                ship_ok=_click_text(page,modes.get(product.get("shipping_mode"),"包邮"))
                location_ok=not product.get("location") or _fill_near_label(page,"宝贝所在地",product.get("location"))
                states.append("发货设置已选择" if ship_ok else "发货设置需手动确认")
                states.append("宝贝所在地已填" if location_ok else "宝贝所在地需手动确认")
                missing=not all((image_ok,desc_ok,price_ok,original_ok,stock_ok,sku_ok,ship_ok,location_ok))
                diag=""
                if missing:
                    diag=_save_failure(page,f"fishshop_{pid}","\n".join(states)+"\n页面保留供人工确认。")
                _save_state(ctx)
                states.append("自动填充结束；请在鱼小铺页面人工检查并决定是否发布。")
                try:page.bring_to_front()
                except Exception:pass
                _wait_for_manual_browser_close(ctx,page)
                return {"ok":True,"partial":missing,"states":states+["鱼小铺浏览器已关闭"],"log_dir":diag}
            except Exception as e:
                folder=_save_failure(page,f"fishshop_{pid}",repr(e)+"\n"+"\n".join(states))
                return {"ok":False,"states":states+[f"异常：{e}"],"log_dir":folder}


PUBLISHERS={"normal":NormalXianyuPublisher(),"fishshop":FishShopPublisher()}


def publisher_for(channel):
    return PUBLISHERS.get(channel,PUBLISHERS["normal"])
