from __future__ import annotations
import os,shutil,subprocess,tempfile,threading,urllib.request,winreg
from pathlib import Path
import tkinter as tk
from tkinter import filedialog,messagebox,ttk

MODEL="qwen3:8b";OLLAMA_URL="https://ollama.com/download/OllamaSetup.exe"


def find_ollama():
    found=shutil.which("ollama")
    if found:return found
    p=Path(os.environ.get("LOCALAPPDATA",""))/"Programs"/"Ollama"/"ollama.exe"
    return str(p) if p.exists() else ""


def set_user_env(name,value):
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER,"Environment") as k:winreg.SetValueEx(k,name,0,winreg.REG_EXPAND_SZ,value)


def install(progress,status,model_dir):
    model_dir.mkdir(parents=True,exist_ok=True);set_user_env("OLLAMA_MODELS",str(model_dir));os.environ["OLLAMA_MODELS"]=str(model_dir)
    exe=find_ollama()
    if not exe:
        status("正在下载 Ollama 官方安装程序…");tmp=Path(tempfile.gettempdir())/"OllamaSetup.exe"
        def hook(block,size,total):progress(min(45,int(block*size*45/max(1,total))))
        urllib.request.urlretrieve(OLLAMA_URL,tmp,hook);status("正在安装 Ollama…")
        subprocess.run([str(tmp),"/S"],check=True);exe=find_ollama()
        if not exe:raise RuntimeError("Ollama 安装后仍未找到，请重启电脑后重新运行 AI 安装包。")
    progress(55);status(f"正在下载本地模型 {MODEL}（文件较大，请保持网络连接）…")
    flags=0x08000000 if os.name=="nt" else 0
    subprocess.run([exe,"pull",MODEL],check=True,creationflags=flags);progress(100);status("AI 环境安装完成")


def main():
    root=tk.Tk();root.title("1688闲鱼助手 AI 安装包");root.geometry("680x370");root.resizable(False,False)
    tk.Label(root,text="1688闲鱼助手 AI 安装包",font=("Microsoft YaHei UI",18,"bold")).pack(pady=(24,8))
    tk.Label(root,text="安装 Ollama 并下载 qwen3:8b 本地模型。模型较大，所需时间取决于网络速度。",wraplength=620,fg="#475467").pack()
    default=Path("D:/AI/OllamaModels") if Path("D:/").exists() else Path(os.environ.get("LOCALAPPDATA",Path.home()))/"OllamaModels"
    path=tk.StringVar(value=str(default));row=tk.Frame(root);row.pack(fill="x",padx=30,pady=25);tk.Label(row,text="模型目录").pack(anchor="w");sub=tk.Frame(row);sub.pack(fill="x",pady=6);tk.Entry(sub,textvariable=path).pack(side="left",fill="x",expand=True);tk.Button(sub,text="浏览…",command=lambda:path.set(filedialog.askdirectory(initialdir=path.get()) or path.get())).pack(side="left",padx=(8,0))
    bar=ttk.Progressbar(root,maximum=100,length=620);bar.pack(pady=8);status=tk.StringVar(value="准备安装");tk.Label(root,textvariable=status,wraplength=620).pack();button=tk.Button(root,text="安装 AI 环境",width=20)
    def go():
        button.config(state="disabled")
        def job():
            try:
                install(lambda v:root.after(0,lambda:bar.config(value=v)),lambda s:root.after(0,lambda:status.set(s)),Path(path.get()))
                root.after(0,lambda:messagebox.showinfo("完成",f"Ollama 与 {MODEL} 已准备完成。"))
            except Exception as e:
                msg=str(e);root.after(0,lambda m=msg:messagebox.showerror("安装失败",m))
            finally:root.after(0,lambda:button.config(state="normal"))
        threading.Thread(target=job,daemon=True).start()
    button.config(command=go);button.pack(pady=18);root.mainloop()


if __name__=="__main__":main()
