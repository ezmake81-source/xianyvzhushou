from main_setup import uninstall_ui

if __name__=="__main__":
    uninstall_ui()
