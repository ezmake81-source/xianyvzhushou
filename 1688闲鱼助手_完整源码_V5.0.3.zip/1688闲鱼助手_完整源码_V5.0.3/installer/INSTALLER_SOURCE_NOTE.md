# V4.0.4 安装器源码说明

V4.0.4 之后的迭代主要集中在安装/卸载层，没有修改 Python 主程序业务逻辑。

当前应用 Python 源码以 `app/` 目录为准；它对应最后一份完整可编辑应用源码（V3.3），
而 V4.0~V4.0.4 只是围绕以下内容反复修正安装器：

- 图形化安装目录选择
- 检测/复用已有 Python 3.12
- 必要时准备私有 Python 3.12
- 创建桌面/开始菜单入口
- 控制面板卸载注册
- AI 独立安装包
- 卸载时“保留商品数据 / 彻底删除数据”
- 卸载程序从 `%TEMP%` 启动独立清理助手，处理安装目录占用
- 使用 `robocopy /MIR` 清空深层 Python runtime 目录

`cleanup_helper_v4_0_4.c` 是 V4.0.4 清理器逻辑。
主安装器 V4.0.4 的最终 PE 二进制放在 `reference_binaries/`，用于行为核对。

后续建议 Work mode 不要继续叠加旧安装器补丁，而应保留其“功能语义”，
重新整理为单一 installer 工程（例如 Inno Setup / NSIS / WiX 或统一 Win32 installer）。
