from __future__ import annotations
import os,shutil,subprocess,sys,tempfile,threading,winreg,zipfile
from pathlib import Path
import tkinter as tk
from tkinter import filedialog,messagebox,ttk

APP_NAME="1688闲鱼助手";APP_ID="1688XianyuAssistant";DATA_APP_ID="1688XianyuAssistantV5";VERSION="5.0.3"
DATA_DIR=Path(os.environ.get("LOCALAPPDATA",Path.home()/"AppData"/"Local"))/DATA_APP_ID
STALE_RUNTIME_FILES=("icuuc.dll","icudt78.dll","libcrypto-3-x64.dll","libssl-3-x64.dll")


def bundle_root():return Path(getattr(sys,"_MEIPASS",Path(__file__).resolve().parent))


def registry_candidates():
    subs=[rf"Software\Microsoft\Windows\CurrentVersion\Uninstall\{APP_ID}",
          rf"Software\Microsoft\Windows\CurrentVersion\Uninstall\{APP_NAME}"]
    for hive in (winreg.HKEY_CURRENT_USER,winreg.HKEY_LOCAL_MACHINE):
        for sub in subs:
            for view in (0,winreg.KEY_WOW64_32KEY,winreg.KEY_WOW64_64KEY):
                try:
                    with winreg.OpenKey(hive,sub,0,winreg.KEY_READ|view) as k:
                        value=winreg.QueryValueEx(k,"InstallLocation")[0]
                        if value:yield Path(value)
                except OSError:pass
    root=r"Software\Microsoft\Windows\CurrentVersion\Uninstall"
    for hive in (winreg.HKEY_CURRENT_USER,winreg.HKEY_LOCAL_MACHINE):
        for view in (0,winreg.KEY_WOW64_32KEY,winreg.KEY_WOW64_64KEY):
            try:
                with winreg.OpenKey(hive,root,0,winreg.KEY_READ|view) as base:
                    for i in range(winreg.QueryInfoKey(base)[0]):
                        try:
                            with winreg.OpenKey(base,winreg.EnumKey(base,i)) as k:
                                name=str(winreg.QueryValueEx(k,"DisplayName")[0])
                                if "1688" in name and ("闲鱼" in name or "Xianyu" in name):
                                    value=winreg.QueryValueEx(k,"InstallLocation")[0]
                                    if value:yield Path(value)
                        except OSError:pass
            except OSError:pass


def old_install_dir():
    for p in registry_candidates():
        if p.exists():return p
    defaults=[Path(os.environ.get("LOCALAPPDATA",Path.home()))/"Programs"/APP_ID,
              Path(os.environ.get("ProgramFiles",r"C:\Program Files"))/APP_ID]
    return next((p for p in defaults if p.exists()),defaults[0])


def safe_install_target(path):
    p=path.expanduser().resolve();anchor=Path(p.anchor)
    if p in {anchor,Path.home().resolve(),DATA_DIR.resolve()} or len(p.parts)<3:
        raise ValueError("安装目录不能是磁盘根目录、用户主目录或用户数据目录。")
    return p


def shortcut(path,target,args=""):
    path.parent.mkdir(parents=True,exist_ok=True)
    vbs=Path(tempfile.gettempdir())/f"xy_shortcut_{os.getpid()}.vbs"
    def q(s):return str(s).replace('"','""')
    # Windows Script Host does not reliably accept UTF-8 BOM for VBScript.
    # UTF-16 is its native Unicode format and also preserves Chinese paths.
    vbs.write_text(f'Set s=CreateObject("WScript.Shell")\r\nSet l=s.CreateShortcut("{q(path)}")\r\nl.TargetPath="{q(target)}"\r\nl.Arguments="{q(args)}"\r\nl.WorkingDirectory="{q(Path(target).parent)}"\r\nl.Save\r\n',encoding="utf-16")
    try:
        subprocess.run(["cscript.exe","//nologo",str(vbs)],check=True,capture_output=True,creationflags=0x08000000)
    finally:
        vbs.unlink(missing_ok=True)


def register_uninstall(target):
    sub=rf"Software\Microsoft\Windows\CurrentVersion\Uninstall\{APP_ID}"
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER,sub) as k:
        vals={"DisplayName":APP_NAME,"DisplayVersion":VERSION,"Publisher":"1688闲鱼助手",
              "InstallLocation":str(target),"DisplayIcon":str(target/"1688XianyuAssistant.exe"),
              "UninstallString":f'"{target/"Uninstall.exe"}" --uninstall'}
        for n,v in vals.items():winreg.SetValueEx(k,n,0,winreg.REG_SZ,v)
        winreg.SetValueEx(k,"NoModify",0,winreg.REG_DWORD,1)


def cleanup_stale_runtime_files(target):
    removed=[]
    for name in STALE_RUNTIME_FILES:
        stale=Path(target)/"_internal"/name
        try:
            if stale.exists():
                stale.unlink();removed.append(name)
        except OSError as e:
            raise RuntimeError(f"无法清理旧运行库 {stale}。请先关闭主程序后重试。\n{e}")
    return removed


def install(target,desktop,startmenu,progress,status):
    payload=bundle_root()/"payload"/"app_payload.zip";target.mkdir(parents=True,exist_ok=True)
    # V5.0.2 stopped packaging these unrelated host DLLs, but an overwrite
    # install can leave the old copies behind.  They shadow Windows/Qt DLLs and
    # make QtWidgets fail before the UI starts.  Remove only the exact known
    # stale files; user data lives outside the program directory.
    cleanup_stale_runtime_files(target)
    with zipfile.ZipFile(payload) as z:
        names=z.infolist();total=max(1,len(names))
        for i,item in enumerate(names):
            z.extract(item,target);progress((i+1)*80//total)
    uninstaller=bundle_root()/"payload"/"Uninstall.exe"
    if not uninstaller.exists():raise RuntimeError("安装包缺少独立卸载程序。")
    shutil.copy2(uninstaller,target/"Uninstall.exe")
    exe=target/"1688XianyuAssistant.exe"
    shortcut_warnings=[]
    if desktop:
        try:shortcut(Path.home()/"Desktop"/f"{APP_NAME}.lnk",exe)
        except Exception as e:shortcut_warnings.append(f"桌面快捷方式：{e}")
    if startmenu:
        menu=Path(os.environ["APPDATA"])/"Microsoft"/"Windows"/"Start Menu"/"Programs"/APP_NAME
        try:
            shortcut(menu/f"{APP_NAME}.lnk",exe);shortcut(menu/"卸载.lnk",target/"Uninstall.exe","--uninstall")
        except Exception as e:shortcut_warnings.append(f"开始菜单快捷方式：{e}")
    register_uninstall(target);progress(100);status("安装完成")
    return shortcut_warnings


def delayed_delete(target,delete_data):
    target=safe_install_target(target)
    if not (target/"1688XianyuAssistant.exe").exists():
        raise RuntimeError("未在目标目录找到主程序，已停止清理以保护其他文件。")
    script=Path(tempfile.gettempdir())/f"1688xy_remove_{os.getpid()}.cmd"
    data=str(DATA_DIR) if delete_data else ""
    script.write_text("@echo off\r\ntimeout /t 2 /nobreak >nul\r\n"+f'rmdir /s /q "{target}"\r\n'+(f'rmdir /s /q "{data}"\r\n' if data else "")+'del "%~f0"\r\n',encoding="mbcs")
    subprocess.Popen(["cmd.exe","/c",str(script)],creationflags=0x08000000)


def uninstall_ui():
    root=tk.Tk();root.title(f"卸载 {APP_NAME}");root.geometry("520x260");target=Path(sys.executable).resolve().parent
    tk.Label(root,text=f"卸载 {APP_NAME} V{VERSION}",font=("Microsoft YaHei UI",15,"bold")).pack(pady=18)
    keep=tk.BooleanVar(value=True);tk.Checkbutton(root,text="保留商品数据库、图片、配置和浏览器登录资料（推荐）",variable=keep,font=("Microsoft YaHei UI",10)).pack(pady=14)
    tk.Label(root,text=f"用户数据位置：{DATA_DIR}",wraplength=480,fg="#555").pack()
    def go():
        if not messagebox.askyesno("确认卸载","确定卸载主程序吗？"):return
        try:winreg.DeleteKey(winreg.HKEY_CURRENT_USER,rf"Software\Microsoft\Windows\CurrentVersion\Uninstall\{APP_ID}")
        except OSError:pass
        for p in [Path.home()/"Desktop"/f"{APP_NAME}.lnk",Path(os.environ["APPDATA"])/"Microsoft"/"Windows"/"Start Menu"/"Programs"/APP_NAME]:
            try:shutil.rmtree(p) if p.is_dir() else p.unlink(missing_ok=True)
            except Exception:pass
        delayed_delete(target,not keep.get());messagebox.showinfo("卸载","卸载清理已启动。");root.destroy()
    tk.Button(root,text="开始卸载",width=18,command=go).pack(pady=22);root.mainloop()


def install_ui():
    root=tk.Tk();root.title(f"{APP_NAME} V{VERSION} 安装程序");root.geometry("680x390");root.resizable(False,False)
    tk.Label(root,text=f"{APP_NAME} V{VERSION}",font=("Microsoft YaHei UI",18,"bold")).pack(pady=(22,5))
    tk.Label(root,text="V5 使用全新的独立空白数据库；不会读取、迁移或修改旧版本商品数据。",fg="#475467",wraplength=620).pack(pady=5)
    frame=tk.Frame(root);frame.pack(fill="x",padx=28,pady=18);tk.Label(frame,text="安装目录",font=("Microsoft YaHei UI",10)).pack(anchor="w")
    path=tk.StringVar(value=str(old_install_dir()));row=tk.Frame(frame);row.pack(fill="x",pady=6);tk.Entry(row,textvariable=path).pack(side="left",fill="x",expand=True);tk.Button(row,text="浏览…",command=lambda:path.set(filedialog.askdirectory(initialdir=path.get()) or path.get())).pack(side="left",padx=(8,0))
    desktop=tk.BooleanVar(value=True);start=tk.BooleanVar(value=True);tk.Checkbutton(frame,text="创建桌面快捷方式",variable=desktop).pack(anchor="w");tk.Checkbutton(frame,text="创建开始菜单快捷方式和卸载入口",variable=start).pack(anchor="w")
    bar=ttk.Progressbar(root,maximum=100,length=620);bar.pack(pady=(10,6));status=tk.StringVar(value="准备安装");tk.Label(root,textvariable=status).pack()
    button=tk.Button(root,text="安装 / 覆盖升级",width=22)
    def run():
        try:target=safe_install_target(Path(path.get()))
        except Exception as e:messagebox.showwarning("安装目录无效",str(e));return
        if not str(target).strip():messagebox.showwarning("提示","请选择安装目录");return
        button.config(state="disabled")
        def job():
            try:
                warnings=install(target,desktop.get(),start.get(),lambda v:root.after(0,lambda:bar.config(value=v)),lambda s:root.after(0,lambda:status.set(s)))
                message="安装完成。V5 已使用独立空白数据库，旧版用户数据未被读取或修改。"
                if warnings:message+="\n\n快捷方式未完全创建，可直接从安装目录启动：\n"+"\n".join(warnings)
                root.after(0,lambda m=message:(messagebox.showinfo("完成",m),root.destroy()))
            except Exception as e:
                msg=str(e);root.after(0,lambda m=msg:messagebox.showerror("安装失败",m));root.after(0,lambda:button.config(state="normal"))
        threading.Thread(target=job,daemon=True).start()
    button.config(command=run);button.pack(pady=12);root.mainloop()


if __name__=="__main__":
    uninstall_ui() if "--uninstall" in sys.argv else install_ui()
