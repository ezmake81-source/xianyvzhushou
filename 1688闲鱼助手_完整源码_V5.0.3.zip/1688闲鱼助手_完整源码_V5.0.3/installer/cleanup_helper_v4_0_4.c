#include "winmini.h"

#define TH32CS_SNAPPROCESS 0x00000002
#define PROCESS_TERMINATE 0x0001
#define PROCESS_QUERY_LIMITED_INFORMATION 0x1000
#define FILE_ATTRIBUTE_NORMAL 0x00000080
#define INVALID_HANDLE_VALUE ((HANDLE)(LONG_PTR)-1)

typedef struct {
  DWORD dwSize, cntUsage, th32ProcessID;
  ULONG_PTR th32DefaultHeapID;
  DWORD th32ModuleID, cntThreads, th32ParentProcessID;
  LONG pcPriClassBase;
  DWORD dwFlags;
  WCHAR szExeFile[260];
} PROCESSENTRY32W_X;

__declspec(dllimport) HANDLE __stdcall CreateToolhelp32Snapshot(DWORD,DWORD);
__declspec(dllimport) BOOL __stdcall Process32FirstW(HANDLE,PROCESSENTRY32W_X*);
__declspec(dllimport) BOOL __stdcall Process32NextW(HANDLE,PROCESSENTRY32W_X*);
__declspec(dllimport) HANDLE __stdcall OpenProcess(DWORD,BOOL,DWORD);
__declspec(dllimport) BOOL __stdcall QueryFullProcessImageNameW(HANDLE,DWORD,LPWSTR,DWORD*);
__declspec(dllimport) BOOL __stdcall TerminateProcess(HANDLE,UINT);
__declspec(dllimport) DWORD __stdcall GetCurrentProcessId(void);
__declspec(dllimport) BOOL __stdcall RemoveDirectoryW(LPCWSTR);
__declspec(dllimport) BOOL __stdcall SetFileAttributesW(LPCWSTR,DWORD);

static WCHAR gInstall[4096],gData[4096],gFlag[32],gTemp[4096],gEmpty[4096],gProc[4096],gCmd[8192];

static WCHAR lower_ascii(WCHAR c){ if(c>='A'&&c<='Z') return c+32; return c; }

static int path_under(LPCWSTR full,LPCWSTR root){
  int i=0;
  if(!full||!root||!root[0]) return 0;
  while(root[i]){
    if(!full[i]) return 0;
    if(lower_ascii(full[i])!=lower_ascii(root[i])) return 0;
    i++;
  }
  return full[i]==0 || full[i]=='\\' || full[i]=='/';
}

static void kill_install_processes(void){
  HANDLE snap;
  PROCESSENTRY32W_X pe;
  DWORD self=GetCurrentProcessId();

  snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
  if(snap==INVALID_HANDLE_VALUE) return;

  pe.dwSize=sizeof(pe);
  if(Process32FirstW(snap,&pe)){
    do{
      HANDLE hp;
      DWORD n=4095;
      if(pe.th32ProcessID==0 || pe.th32ProcessID==self) continue;
      hp=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|PROCESS_TERMINATE,FALSE,pe.th32ProcessID);
      if(!hp) continue;
      gProc[0]=0;
      if(QueryFullProcessImageNameW(hp,0,gProc,&n) && path_under(gProc,gInstall)){
        TerminateProcess(hp,0);
      }
      CloseHandle(hp);
    }while(Process32NextW(snap,&pe));
  }
  CloseHandle(snap);
}

static int purge_tree(LPCWSTR target){
  int i;
  if(!target || !target[0]) return 1;
  if(GetFileAttributesW(target)==INVALID_FILE_ATTRIBUTES) return 1;

  for(i=0;i<18;i++){
    wsprintfW(
      gCmd,
      L"robocopy.exe \"%s\" \"%s\" /MIR /XJ /R:1 /W:1 /NFL /NDL /NJH /NJS /NC /NS /NP",
      gEmpty,target
    );
    run_wait(gCmd,gTemp);

    SetFileAttributesW(target,FILE_ATTRIBUTE_NORMAL);
    RemoveDirectoryW(target);

    if(GetFileAttributesW(target)==INVALID_FILE_ATTRIBUTES) return 1;
    Sleep(650);
  }
  return 0;
}

void __stdcall WinMainCRTStartup(void){
  DWORD pid=GetCurrentProcessId();
  int full=0;

  GetEnvironmentVariableW(L"XY_INSTALL_DIR",gInstall,4096);
  GetEnvironmentVariableW(L"XY_DATA_DIR",gData,4096);
  GetEnvironmentVariableW(L"XY_DELETE_DATA",gFlag,32);
  GetTempPathW(4096,gTemp);

  if(!gInstall[0]) ExitProcess(2);
  if(gFlag[0]=='1') full=1;

  wsprintfW(gEmpty,L"%s1688xy_empty_%lu",gTemp,pid);
  CreateDirectoryW(gEmpty,NULL);

  Sleep(1800);
  kill_install_processes();
  Sleep(300);
  purge_tree(gInstall);

  if(full && gData[0]){
    purge_tree(gData);
  }

  RemoveDirectoryW(gEmpty);
  ExitProcess(0);
}
