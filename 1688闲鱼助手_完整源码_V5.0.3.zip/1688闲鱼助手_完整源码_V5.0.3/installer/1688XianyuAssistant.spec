# -*- mode: python ; coding: utf-8 -*-
import os
from pathlib import Path
from PyInstaller.utils.hooks import collect_all

project = Path(os.environ["XIANYU_BUILD_PROJECT"])
datas = [(str(project / "app" / "docs"), "docs")]
binaries = []
hiddenimports = []
collected = collect_all("playwright")
datas += collected[0]
binaries += collected[1]
hiddenimports += collected[2]

a = Analysis(
    [str(project / "app" / "app.py")],
    pathex=[str(project / "app")],
    binaries=binaries,
    datas=datas,
    hiddenimports=hiddenimports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)

# The Codex host exposes unrelated PDF/image helper DLLs to every child
# process.  Qt imports the Windows ICU shim by name, so PyInstaller can mistake
# a Poppler ICU on that host path for a Qt dependency.  Never ship host helper
# binaries in the standalone application.
a.binaries = [
    entry for entry in a.binaries
    if "codex-runtimes" not in str(entry[1]).lower()
]

pyz = PYZ(a.pure)
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="1688XianyuAssistant",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="1688XianyuAssistant",
)
