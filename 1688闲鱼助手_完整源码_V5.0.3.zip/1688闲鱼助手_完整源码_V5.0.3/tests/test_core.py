import os,sys,tempfile,unittest,sqlite3,hashlib,json
from pathlib import Path

TEST_ROOT=Path(__file__).resolve().parents[1]/"build"/"test-data"
TEST_ROOT.mkdir(parents=True,exist_ok=True)
TEST_DATA=TEST_ROOT
os.environ["LOCALAPPDATA"]=str(TEST_DATA)
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"app"))

from core import db
from core.config import DATA_ROOT
from core.description import description_with_attributes
from core.pricing import calc_price,derive_parameter,metrics
from core.scraper import _best_structured
from core.legacy_import import import_v4_database


class CoreTests(unittest.TestCase):
    def setUp(self):db.init_db()

    def test_old_pricing_is_compatible(self):
        self.assertEqual(calc_price(70,"margin",30),100)
        self.assertEqual(derive_parameter(70,100,"margin"),30)

    def test_fishshop_fee_is_explicit(self):
        price=calc_price(70,"margin",30,0,.01)
        self.assertEqual(price,101.45)
        profit,margin,fee=metrics(70,price,0,.01)
        self.assertAlmostEqual(fee,1.01,places=2)
        self.assertAlmostEqual(margin,30,places=1)

    def test_migration_and_roundtrip(self):
        pid=db.create_product({"source_url":"https://detail.1688.com/offer/1.html","source_title":"测试","shipping_cost":None,"shipping_cost_unknown":True,"price_tiers":[{"min_qty":1,"price":8.8}],"attrs":{"材质":"棉"},"sku":[{"name":"白色/M","price":19.9,"stock":"5"}],"publish_channel":"fishshop"})
        p=db.get_product(pid)
        self.assertEqual(p["publish_channel"],"fishshop");self.assertTrue(p["shipping_cost_unknown"])
        self.assertEqual(p["attrs"]["材质"],"棉");self.assertEqual(p["sku"][0]["stock"],"5")

    def test_v4_database_migrates_without_losing_row(self):
        legacy=TEST_ROOT/"legacy.db";legacy.unlink(missing_ok=True)
        with sqlite3.connect(legacy) as c:
            c.executescript("""CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT);
            CREATE TABLE products(id INTEGER PRIMARY KEY AUTOINCREMENT,source_url TEXT NOT NULL DEFAULT '',offer_id TEXT DEFAULT '',source_title TEXT DEFAULT '',shop_name TEXT DEFAULT '',ai_title TEXT DEFAULT '',description TEXT DEFAULT '',ai_instruction TEXT DEFAULT '',cost REAL DEFAULT 0,sale_price REAL DEFAULT 0,pricing_mode TEXT DEFAULT 'multiplier',pricing_value REAL DEFAULT 1.6,stock TEXT DEFAULT '',min_order TEXT DEFAULT '',sku_json TEXT DEFAULT '[]',attrs_json TEXT DEFAULT '{}',images_json TEXT DEFAULT '[]',image_types_json TEXT DEFAULT '{}',posts_json TEXT DEFAULT '[]',status TEXT DEFAULT '待处理',publish_state TEXT DEFAULT '',last_error TEXT DEFAULT '',created_at TEXT NOT NULL,updated_at TEXT NOT NULL);
            INSERT INTO products(source_url,source_title,created_at,updated_at) VALUES('old','旧商品','2026-01-01','2026-01-01');""")
        original=db.DB_PATH;db.DB_PATH=legacy
        try:
            db.init_db();p=db.get_product(1)
            self.assertEqual(p["source_title"],"旧商品");self.assertEqual(p["publish_channel"],"normal")
            self.assertTrue(p["shipping_cost_unknown"])
        finally:db.DB_PATH=original

    def test_v5_starts_blank_and_does_not_touch_legacy_database(self):
        self.assertEqual(DATA_ROOT.name,"1688XianyuAssistantV5")
        legacy=TEST_ROOT/"legacy-untouched.db";blank=TEST_ROOT/"v5-blank.db"
        legacy.write_bytes(b"legacy database sentinel");blank.unlink(missing_ok=True)
        before=hashlib.sha256(legacy.read_bytes()).hexdigest();original=db.DB_PATH;db.DB_PATH=blank
        try:
            db.init_db()
            self.assertEqual(db.list_products(),[])
        finally:db.DB_PATH=original
        self.assertEqual(hashlib.sha256(legacy.read_bytes()).hexdigest(),before)

    def test_structured_1688_values(self):
        data={"offerTitle":"示例商品","priceRangeList":[{"beginAmount":1,"price":"12.5"},{"beginAmount":10,"price":"10"}],"onePiecePrice":"13.8","freightFee":"6","attributes":[{"name":"材质","value":"木"}],"skuMap":{"红色":{"discountPrice":"13.8","stock":9}}}
        x=_best_structured([data])
        self.assertEqual(x["price"],13.8);self.assertEqual(x["shipping_cost"],6)
        self.assertEqual(x["attrs"]["材质"],"木");self.assertEqual(len(x["price_tiers"]),2);self.assertEqual(x["sku"][0]["stock"],"9")

    def test_attribute_description_is_idempotent(self):
        once=description_with_attributes("正文",{"材质":"木"},True)
        self.assertEqual(description_with_attributes(once,{"材质":"木"},True),once)

    def test_v4_import_is_read_only_and_idempotent(self):
        folder=Path(__file__).resolve().parent/"test-data"/"v4_import"
        folder.mkdir(parents=True,exist_ok=True)
        source=folder/"products.db";image=folder/"old.jpg";image.write_bytes(b"image")
        source.unlink(missing_ok=True)
        with sqlite3.connect(source) as c:
            c.executescript("""CREATE TABLE products(
            id INTEGER PRIMARY KEY AUTOINCREMENT,source_url TEXT NOT NULL DEFAULT '',offer_id TEXT DEFAULT '',
            source_title TEXT DEFAULT '',shop_name TEXT DEFAULT '',ai_title TEXT DEFAULT '',description TEXT DEFAULT '',
            ai_instruction TEXT DEFAULT '',cost REAL DEFAULT 0,sale_price REAL DEFAULT 0,
            pricing_mode TEXT DEFAULT 'multiplier',pricing_value REAL DEFAULT 1.6,stock TEXT DEFAULT '',
            min_order TEXT DEFAULT '',sku_json TEXT DEFAULT '[]',attrs_json TEXT DEFAULT '{}',
            images_json TEXT DEFAULT '[]',image_types_json TEXT DEFAULT '{}',posts_json TEXT DEFAULT '[]',
            status TEXT DEFAULT '待处理',publish_state TEXT DEFAULT '',last_error TEXT DEFAULT '',
            created_at TEXT NOT NULL,updated_at TEXT NOT NULL);""")
            c.execute("INSERT INTO products(source_url,source_title,images_json,created_at,updated_at) VALUES(?,?,?,?,?)",
                      ("https://detail.1688.com/offer/import-test.html","V4导入商品",json.dumps([str(image)]),"2026-01-01","2026-01-02"))
        source_key=str(source.resolve()).casefold()
        with db.conn() as c:
            mapped=[r[0] for r in c.execute("SELECT product_id FROM legacy_imports WHERE source_db=?",(source_key,))]
            if mapped:c.executemany("DELETE FROM products WHERE id=?",[(x,) for x in mapped])
            c.execute("DELETE FROM legacy_imports WHERE source_db=?",(source_key,))
        before=hashlib.sha256(source.read_bytes()).hexdigest()
        first=import_v4_database(source);second=import_v4_database(source)
        self.assertEqual(first["imported"],1)
        imported_product=next(p for p in db.list_products() if p["source_url"].endswith("import-test.html"))
        self.assertTrue(imported_product["images"]);self.assertTrue(Path(imported_product["images"][0]).is_file())
        self.assertEqual(second["imported"],0);self.assertEqual(second["skipped"],1)
        self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(),before)


if __name__=="__main__":unittest.main()
