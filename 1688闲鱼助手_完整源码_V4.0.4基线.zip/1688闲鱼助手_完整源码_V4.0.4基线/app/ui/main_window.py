from __future__ import annotations
from pathlib import Path
from PySide6.QtCore import Qt,QSize
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import *
from core import db
from core.scraper import scrape_1688
from core.ai import generate_copy
from core.pricing import calc_price
from core.workers import JobThread
from core.xianyu import fill_xianyu, login_xianyu
from core.backup import create_backup
from core.csvio import export_csv,import_csv
from .product_dialog import ProductDialog
from .image_manager import ImageManagerDialog
from .add_dialog import AddDialog
from .diagnostics_dialog import DiagnosticsDialog
from .ai_settings import AISettingsDialog
from .help_dialog import HelpDialog

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__();self.setWindowTitle("1688 → 闲鱼助手 V3.3.3.2.2");self.resize(1460,900);self.threads=[];self.build();self.refresh()
    def build(self):
        root=QWidget();self.setCentralWidget(root);l=QVBoxLayout(root)
        top=QHBoxLayout()
        self.add=QPushButton("添加商品");self.add.clicked.connect(self.add_product)
        self.search=QLineEdit();self.search.setPlaceholderText("搜索标题 / 店铺 / 链接");self.search.returnPressed.connect(self.refresh)
        self.sys=QPushButton("系统状态");self.sys.clicked.connect(lambda:DiagnosticsDialog(self).exec())
        self.ai=QPushButton("AI设置");self.ai.clicked.connect(lambda:AISettingsDialog(self).exec())
        self.help=QPushButton("使用教程");self.help.clicked.connect(lambda:HelpDialog(self).exec())
        top.addWidget(self.add);top.addWidget(self.search,1);top.addWidget(self.help);top.addWidget(self.ai);top.addWidget(self.sys);l.addLayout(top)
        row=QHBoxLayout()
        for txt,fn in [("全选",self.select_all),("取消全选",self.clear_all),("编辑",self.edit),("删除",self.delete),
                       ("AI生成",self.ai_generate),("批量重算售价",self.reprice),("闲鱼登录",self.xianyu_login),("闲鱼填充",self.publish),
                       ("导出CSV",self.export),("导入CSV",self.import_),("备份数据",self.backup)]:
            b=QPushButton(txt);b.clicked.connect(fn);row.addWidget(b)
        row.addStretch(1);l.addLayout(row)
        self.table=QTableWidget(0,11);self.table.setHorizontalHeaderLabels(["选择","缩略图","ID","标题","店铺","成本","售价","定价","图片","状态","来源"])
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows);self.table.setEditTriggers(QAbstractItemView.NoEditTriggers);self.table.verticalHeader().setDefaultSectionSize(74)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents);self.table.horizontalHeader().setSectionResizeMode(3,QHeaderView.Stretch);self.table.horizontalHeader().setSectionResizeMode(10,QHeaderView.Stretch)
        self.table.doubleClicked.connect(self.edit);l.addWidget(self.table,1)
        self.status=QLabel("就绪");l.addWidget(self.status)

    def ids(self):
        out=[]
        for r in range(self.table.rowCount()):
            it=self.table.item(r,0)
            if it and it.checkState()==Qt.Checked:out.append(int(self.table.item(r,2).text()))
        if not out:
            rows={i.row() for i in self.table.selectedIndexes()}
            out=[int(self.table.item(r,2).text()) for r in rows]
        return out
    def refresh(self):
        rows=db.list_products(self.search.text().strip());self.table.setRowCount(len(rows))
        for r,p in enumerate(rows):
            c=QTableWidgetItem();c.setCheckState(Qt.Unchecked);self.table.setItem(r,0,c)
            lab=QLabel();lab.setFixedSize(64,64);lab.setAlignment(Qt.AlignCenter);lab.setCursor(Qt.PointingHandCursor);lab.setToolTip("点击查看/修改图片")
            if p.get("images"):
                q=Path(p["images"][0])
                if q.exists():lab.setPixmap(QPixmap(str(q)).scaled(64,64,Qt.KeepAspectRatio,Qt.SmoothTransformation))
            lab.mousePressEvent=lambda e,pid=p["id"]:self.images(pid)
            self.table.setCellWidget(r,1,lab)
            vals=[str(p["id"]),p.get("ai_title") or p.get("source_title",""),p.get("shop_name",""),f'{float(p.get("cost",0)):.2f}',f'{float(p.get("sale_price",0)):.2f}',
                  f'{p.get("pricing_mode","")} / {p.get("pricing_value","")}',str(len(p.get("images",[]))),p.get("status",""),p.get("source_url","")]
            for j,v in enumerate(vals,2):self.table.setItem(r,j,QTableWidgetItem(v))
        self.status.setText(f"共 {len(rows)} 个商品")
    def select_all(self):
        for r in range(self.table.rowCount()):self.table.item(r,0).setCheckState(Qt.Checked)
    def clear_all(self):
        for r in range(self.table.rowCount()):self.table.item(r,0).setCheckState(Qt.Unchecked)
    def add_product(self):
        d=AddDialog(self)
        if not d.exec():return
        mode,url=d.result_data()
        if mode==1:
            e=ProductDialog(parent=self)
            if e.exec():
                x=e.data()
                if not x["sale_price"]:x["sale_price"]=calc_price(x["cost"],x["pricing_mode"],x["pricing_value"])
                db.create_product(x);self.refresh()
            return
        if not url:return QMessageBox.information(self,"提示","请输入1688链接")
        self.status.setText("正在采集1688商品...")
        th=JobThread(scrape_1688,url);self.threads.append(th);th.ok.connect(self.collect_ok);th.fail.connect(self.fail);th.start()
    def collect_ok(self,x):
        x["pricing_mode"]="margin";x["pricing_value"]=30.0;x["sale_price"]=calc_price(x.get("cost",0),"margin",30.0)
        db.create_product(x);self.refresh();self.status.setText(f"采集完成：{x.get('source_title','')}，图片 {len(x.get('images',[]))} 张")
    def fail(self,s):QMessageBox.critical(self,"任务失败",s[-4000:]);self.status.setText("任务失败")
    def edit(self,*_):
        ids=self.ids()
        if not ids:return
        p=db.get_product(ids[0]);d=ProductDialog(p,self)
        if d.exec():db.update_product(ids[0],d.data());self.refresh()
    def delete(self):
        ids=self.ids()
        if ids and QMessageBox.question(self,"确认",f"删除 {len(ids)} 个商品？")==QMessageBox.Yes:db.delete_products(ids);self.refresh()
    def images(self,pid):
        p=db.get_product(pid);d=ImageManagerDialog(p.get("images",[]),self)
        if d.exec():db.update_product(pid,{"images":d.images()});self.refresh()
    def ai_generate(self):
        ids=self.ids()
        if not ids:return QMessageBox.information(self,"提示","请选择商品")
        ins,ok=QInputDialog.getMultiLineText(self,"AI要求","例如：像个人卖家，避免营销腔；标题突出复古感；描述150字以内。")
        if not ok:return
        providers=[]
        for pid in ids:
            p=db.get_product(pid);x=generate_copy(p,ins);providers.append(x["provider"])
            db.update_product(pid,{"ai_title":x["title"],"description":x["description"],"posts":x["posts"],"ai_instruction":ins,"status":"待发布"})
        self.refresh();QMessageBox.information(self,"完成","AI生成完成\n使用："+ "、".join(sorted(set(providers))))
    def reprice(self):
        for pid in self.ids():
            p=db.get_product(pid);db.update_product(pid,{"sale_price":calc_price(p["cost"],p["pricing_mode"],p["pricing_value"])})
        self.refresh()
    def xianyu_login(self):
        self.status.setText('正在打开闲鱼登录窗口...')
        th=JobThread(login_xianyu);self.threads.append(th);th.ok.connect(self.xianyu_login_ok);th.fail.connect(self.fail);th.start()
    def xianyu_login_ok(self,x):
        self.status.setText('闲鱼登录状态已更新' if x.get('ok') else '闲鱼登录未完成')
        QMessageBox.information(self,'闲鱼登录','\n'.join(x.get('states',[])))

    def publish(self):
        ids=self.ids()
        if not ids:return
        pid=ids[0];p=db.get_product(pid);db.set_status([pid],"处理中","正在填充");self.refresh();self.status.setText("正在导入闲鱼发布数据；完成后浏览器会一直保持打开，直到你手动关闭。")
        th=JobThread(fill_xianyu,p);self.threads.append(th);th.ok.connect(lambda x,pid=pid:self.publish_ok(pid,x));th.fail.connect(self.fail);th.start()
    def publish_ok(self,pid,x):
        if x.get("ok"):db.set_status([pid],"已填充","人工审阅中/已结束","")
        else:db.set_status([pid],"失败","填充失败",x.get("log_dir",""))
        self.refresh()
        QMessageBox.information(self,"闲鱼结果","\n".join(x.get("states",[])) + (f"\n日志：{x.get('log_dir')}" if x.get("log_dir") else ""))
    def export(self):
        p,_=QFileDialog.getSaveFileName(self,"导出CSV","products.csv","CSV (*.csv)")
        if p:export_csv(p);QMessageBox.information(self,"完成","导出完成")
    def import_(self):
        p,_=QFileDialog.getOpenFileName(self,"导入CSV","","CSV (*.csv)")
        if p:n=import_csv(p);self.refresh();QMessageBox.information(self,"完成",f"导入/更新 {n} 条")
    def backup(self):
        p=create_backup();QMessageBox.information(self,"备份完成",str(p))
