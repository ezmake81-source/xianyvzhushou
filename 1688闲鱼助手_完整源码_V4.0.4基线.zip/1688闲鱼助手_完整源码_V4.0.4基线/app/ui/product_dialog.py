from __future__ import annotations
from PySide6.QtGui import QDoubleValidator
from PySide6.QtWidgets import *
from core.pricing import calc_price, derive_parameter, metrics
from .image_manager import ImageManagerDialog

class ProductDialog(QDialog):
    def __init__(self,p=None,parent=None):
        super().__init__(parent)
        self.p=p or {}; self._images=list(self.p.get('images',[])); self._syncing=False
        self.setWindowTitle('商品编辑'); self.resize(820,820)
        lay=QVBoxLayout(self); form=QFormLayout()
        self.url=QLineEdit(self.p.get('source_url','')); self.source=QLineEdit(self.p.get('source_title','')); self.shop=QLineEdit(self.p.get('shop_name',''))
        self.ai=QLineEdit(self.p.get('ai_title','')); self.desc=QTextEdit(self.p.get('description','')); self.ins=QTextEdit(self.p.get('ai_instruction',''))
        is_new=not bool(self.p)
        default_mode='margin' if is_new else self.p.get('pricing_mode','margin')
        default_value=30.0 if is_new else float(self.p.get('pricing_value',30) or 30)
        self.cost=QLineEdit(str(self.p.get('cost',0) or 0)); self.cost.setValidator(QDoubleValidator(0,999999,4,self))
        self.mode=QComboBox()
        for t,d in [('毛利率 %','margin'),('倍率','multiplier'),('固定加价','profit'),('固定售价','fixed')]: self.mode.addItem(t,d)
        self.mode.setCurrentIndex(max(0,self.mode.findData(default_mode)))
        self.val=QLineEdit(str(default_value)); self.val.setValidator(QDoubleValidator(0,999999,4,self))
        sale=self.p.get('sale_price',0) or 0
        if is_new and float(self.p.get('cost',0) or 0)>0: sale=calc_price(float(self.p.get('cost',0)),default_mode,default_value)
        self.sale=QLineEdit(str(sale)); self.sale.setValidator(QDoubleValidator(0,999999,4,self))
        self.status=QComboBox(); self.status.addItems(['待处理','已采集','待发布','处理中','已填充','已发布','失败']); self.status.setCurrentText(self.p.get('status','待处理'))
        for label,w in [('1688链接',self.url),('原始标题',self.source),('店铺',self.shop),('AI标题',self.ai),('商品描述',self.desc),('AI额外要求',self.ins),('采购成本',self.cost),('定价方式',self.mode),('定价参数',self.val),('闲鱼售价',self.sale),('状态',self.status)]: form.addRow(label,w)
        lay.addLayout(form)
        self.metric=QLabel(); lay.addWidget(self.metric)
        hint=QLabel('联动规则：修改采购成本或定价参数 → 自动更新闲鱼售价；修改闲鱼售价 → 自动反算定价参数。'); hint.setWordWrap(True); lay.addWidget(hint)
        self.imgbtn=QPushButton(f'管理图片（{len(self._images)} 张）'); self.imgbtn.clicked.connect(self.images); lay.addWidget(self.imgbtn)
        self.thumb=QListWidget(); self.thumb.setViewMode(QListWidget.ListMode); lay.addWidget(self.thumb,1); self.reload_images()
        bb=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel); bb.accepted.connect(self.accept); bb.rejected.connect(self.reject); lay.addWidget(bb)
        self.cost.textEdited.connect(self.sync_from_cost_or_param); self.val.textEdited.connect(self.sync_from_cost_or_param); self.sale.textEdited.connect(self.sync_from_sale); self.mode.currentIndexChanged.connect(self.mode_changed)
        self.update_metric()
    def num(self,w):
        try:return float(w.text())
        except:return 0.0
    def _set_text(self,w,value,decimals=2): w.setText(f'{float(value):.{decimals}f}'.rstrip('0').rstrip('.'))
    def sync_from_cost_or_param(self,*_):
        if self._syncing:return
        self._syncing=True
        try:self._set_text(self.sale,calc_price(self.num(self.cost),self.mode.currentData(),self.num(self.val)),2); self.update_metric()
        finally:self._syncing=False
    def sync_from_sale(self,*_):
        if self._syncing:return
        self._syncing=True
        try:self._set_text(self.val,derive_parameter(self.num(self.cost),self.num(self.sale),self.mode.currentData()),2); self.update_metric()
        finally:self._syncing=False
    def mode_changed(self,*_):
        if self._syncing:return
        self._syncing=True
        try:
            param=derive_parameter(self.num(self.cost),self.num(self.sale),self.mode.currentData())
            if self.mode.currentData()=='margin' and self.num(self.sale)<=0:param=30.0
            self._set_text(self.val,param,2); self.update_metric()
        finally:self._syncing=False
    def update_metric(self,*_):
        profit,margin=metrics(self.num(self.cost),self.num(self.sale)); self.metric.setText(f'预计单件毛利：{profit:.2f} 元    毛利率：{margin:.1f}%    当前模式：{self.mode.currentText()} {self.num(self.val):.2f}')
    def reload_images(self):
        self.thumb.clear()
        for p in self._images:self.thumb.addItem(p)
        self.imgbtn.setText(f'管理图片（{len(self._images)} 张）')
    def images(self):
        d=ImageManagerDialog(self._images,self)
        if d.exec():self._images=d.images(); self.reload_images()
    def data(self):
        return {'source_url':self.url.text().strip(),'source_title':self.source.text().strip(),'shop_name':self.shop.text().strip(),'ai_title':self.ai.text().strip(),'description':self.desc.toPlainText().strip(),'ai_instruction':self.ins.toPlainText().strip(),'cost':self.num(self.cost),'pricing_mode':self.mode.currentData(),'pricing_value':self.num(self.val),'sale_price':self.num(self.sale),'status':self.status.currentText(),'images':self._images}
