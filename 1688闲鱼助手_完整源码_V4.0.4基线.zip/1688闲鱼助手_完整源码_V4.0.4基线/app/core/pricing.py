def calc_price(cost:float, mode:str, value:float)->float:
    cost=max(0.0,float(cost or 0)); value=float(value or 0)
    if mode=='multiplier': price=cost*value
    elif mode=='margin':
        m=min(max(value/100.0,0),0.95); price=cost/(1-m) if m<1 else cost
    elif mode=='profit': price=cost+value
    elif mode=='fixed': price=value
    else: price=cost
    return round(max(0.0,price),2)

def derive_parameter(cost:float, sale:float, mode:str)->float:
    cost=max(0.0,float(cost or 0)); sale=max(0.0,float(sale or 0))
    if mode=='multiplier': return round(sale/cost,4) if cost>0 else 0.0
    if mode=='margin': return round(((sale-cost)/sale)*100,2) if sale>0 else 0.0
    if mode=='profit': return round(sale-cost,2)
    if mode=='fixed': return round(sale,2)
    return 0.0

def metrics(cost:float, sale:float):
    cost=float(cost or 0); sale=float(sale or 0); profit=sale-cost
    margin=(profit/sale*100) if sale>0 else 0
    return round(profit,2), round(margin,2)
