from __future__ import annotations
import hashlib, json, mimetypes, re, time
from pathlib import Path
from urllib.parse import urlparse
import requests
from .browser import persistent_browser
from .config import PROFILE_1688, IMAGE_DIR

OFFER_RE=re.compile(r"/offer/(\d+)\.html")

def offer_id_from_url(url):
    m=OFFER_RE.search(url or "")
    return m.group(1) if m else ""

def _clean_url(u):
    if not u:return ""
    u=u.replace("\\u002F","/").replace("\\/","/").replace("&amp;","&").strip()
    if u.startswith("//"):u="https:"+u
    return u

def _extract_json_candidates(html):
    out=[]
    for pat in [
        r'window\.__INIT_DATA__\s*=\s*({.*?})\s*;</script>',
        r'window\.__INITIAL_STATE__\s*=\s*({.*?})\s*;</script>',
        r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>',
    ]:
        for m in re.finditer(pat,html,re.S|re.I):
            txt=m.group(1).strip()
            try: out.append(json.loads(txt))
            except Exception: pass
    return out

def _walk(obj):
    if isinstance(obj,dict):
        for k,v in obj.items():
            yield k,v
            yield from _walk(v)
    elif isinstance(obj,list):
        for v in obj: yield from _walk(v)

def _best_structured(data_list):
    result={"title":"","shop_name":"","price":0.0,"stock":"","min_order":"","sku":[],"attrs":{}}
    title_keys={"title","subject","offerTitle","productTitle","name"}
    shop_keys={"shopName","sellerName","companyName"}
    price_keys={"price","priceText","offerPrice","currentPrice"}
    for data in data_list:
        for k,v in _walk(data):
            if not result["title"] and k in title_keys and isinstance(v,str) and len(v.strip())>4:
                result["title"]=v.strip()
            if not result["shop_name"] and k in shop_keys and isinstance(v,str):
                result["shop_name"]=v.strip()
            if k in price_keys and not result["price"]:
                s=str(v)
                m=re.search(r"(\d+(?:\.\d{1,2})?)",s)
                if m:
                    x=float(m.group(1))
                    if 0<x<100000: result["price"]=x
    return result

def _text(page, selectors):
    for sel in selectors:
        try:
            loc=page.locator(sel).first
            if loc.count() and loc.is_visible():
                t=loc.inner_text(timeout=1200).strip()
                if t:return t
        except Exception: pass
    return ""

def _price_from_text(t):
    vals=[]
    for n in re.findall(r"(?<!\d)(\d+(?:\.\d{1,2})?)(?!\d)",(t or "").replace(",","")):
        try:
            v=float(n)
            if 0<v<100000:vals.append(v)
        except: pass
    return min(vals) if vals else 0.0

def _image_score(url):
    u=url.lower()
    s=0
    if any(x in u for x in ["alicdn","detail","offer","sku"]): s+=3
    if any(x in u for x in ["logo","avatar","icon","sprite","qr","80x80","60x60","100x100"]): s-=10
    return s

def _collect_images(page):
    urls=set()
    for _ in range(10):
        try:
            page.mouse.wheel(0,900)
            page.wait_for_timeout(250)
        except: pass
    try:
        imgs=page.locator("img")
        for i in range(min(imgs.count(),700)):
            el=imgs.nth(i)
            for attr in ("src","data-src","data-lazyload-src","data-original","srcset"):
                try:v=el.get_attribute(attr) or ""
                except:v=""
                if not v:continue
                if attr=="srcset":
                    for p in v.split(","):urls.add(_clean_url(p.strip().split(" ")[0]))
                else:urls.add(_clean_url(v))
    except: pass
    try:
        html=page.content()
        for u in re.findall(r'https?://[^"\'\s<>]+?\.(?:jpg|jpeg|png|webp)(?:\?[^"\'\s<>]*)?',html,re.I):
            urls.add(_clean_url(u))
    except: pass
    return sorted([u for u in urls if u.startswith("http") and _image_score(u)>-4], key=_image_score, reverse=True)[:160]

def _guess_ext(url,ct=""):
    p=urlparse(url).path.lower()
    for e in (".jpg",".jpeg",".png",".webp"):
        if p.endswith(e):return ".jpg" if e==".jpeg" else e
    return mimetypes.guess_extension(ct.split(";")[0].strip()) or ".jpg"

def _download(urls,offer_id,maxn=24):
    target=IMAGE_DIR/(offer_id or "unknown")
    target.mkdir(parents=True,exist_ok=True)
    sess=requests.Session()
    sess.headers.update({"User-Agent":"Mozilla/5.0","Referer":"https://detail.1688.com/"})
    saved=[]; seen=set()
    for u in urls:
        if len(saved)>=maxn:break
        try:
            r=sess.get(u,timeout=15)
            if r.status_code!=200 or len(r.content)<12000:continue
            h=hashlib.sha1(r.content).hexdigest()
            if h in seen:continue
            seen.add(h)
            p=target/f"{len(saved)+1:02d}_{h[:8]}{_guess_ext(u,r.headers.get('content-type',''))}"
            p.write_bytes(r.content); saved.append(str(p))
        except:pass
    return saved

def scrape_1688(url):
    oid=offer_id_from_url(url)
    with persistent_browser(PROFILE_1688,False) as ctx:
        page=ctx.pages[0] if ctx.pages else ctx.new_page()
        page.goto(url,wait_until="domcontentloaded",timeout=90000)
        page.wait_for_timeout(2500)
        html=page.content()
        structured=_best_structured(_extract_json_candidates(html))

        title=structured["title"]
        if not title:
            title=_text(page,[
                "[data-testid='offer-title']",
                "[class*='offer-title']",
                "[class*='product-title']",
                "h1"
            ])
        shop=structured["shop_name"] or _text(page,[
            "[class*='company']","[class*='shop-name']","[class*='seller']"
        ])
        # 避免误把公司名当商品名
        if title and shop and title.strip()==shop.strip():
            title=""
        if not title:
            try:
                pt=page.title().strip()
                title=re.sub(r"[-_丨|].*$","",pt).strip()
            except:title=""

        price=structured["price"]
        if not price:
            price=_price_from_text(_text(page,[
                "[class*='price']","[class*='Price']","[data-testid*='price']"
            ]))
        images=_download(_collect_images(page),oid)
        return {
            "source_url":url,"offer_id":oid,"source_title":title[:300],"shop_name":shop[:200],
            "cost":price,"stock":structured["stock"],"min_order":structured["min_order"],
            "sku":structured["sku"],"attrs":structured["attrs"],"images":images,
            "image_types":{"main":images[:6],"sku":[],"detail":images[6:]},
            "status":"已采集"
        }
