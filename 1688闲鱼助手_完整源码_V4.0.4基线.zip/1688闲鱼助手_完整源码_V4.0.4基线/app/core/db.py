from __future__ import annotations
import sqlite3, json
from datetime import datetime
from typing import Any, Iterable
from .config import DB_PATH

SCHEMA_VERSION = 3

def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    return c

def _now():
    return datetime.now().isoformat(timespec="seconds")

def init_db():
    with conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS meta(
            key TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS products(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source_url TEXT NOT NULL DEFAULT '',
            offer_id TEXT DEFAULT '',
            source_title TEXT DEFAULT '',
            shop_name TEXT DEFAULT '',
            ai_title TEXT DEFAULT '',
            description TEXT DEFAULT '',
            ai_instruction TEXT DEFAULT '',
            cost REAL DEFAULT 0,
            sale_price REAL DEFAULT 0,
            pricing_mode TEXT DEFAULT 'multiplier',
            pricing_value REAL DEFAULT 1.6,
            stock TEXT DEFAULT '',
            min_order TEXT DEFAULT '',
            sku_json TEXT DEFAULT '[]',
            attrs_json TEXT DEFAULT '{}',
            images_json TEXT DEFAULT '[]',
            image_types_json TEXT DEFAULT '{}',
            posts_json TEXT DEFAULT '[]',
            status TEXT DEFAULT '待处理',
            publish_state TEXT DEFAULT '',
            last_error TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        """)
        c.execute("INSERT OR REPLACE INTO meta(key,value) VALUES('schema_version',?)", (str(SCHEMA_VERSION),))
        c.commit()

def _loads(s, default):
    try: return json.loads(s or "")
    except Exception: return default

def _row(row):
    if not row: return None
    d = dict(row)
    d["sku"] = _loads(d.pop("sku_json","[]"), [])
    d["attrs"] = _loads(d.pop("attrs_json","{}"), {})
    d["images"] = _loads(d.pop("images_json","[]"), [])
    d["image_types"] = _loads(d.pop("image_types_json","{}"), {})
    d["posts"] = _loads(d.pop("posts_json","[]"), [])
    return d

def list_products(search=""):
    with conn() as c:
        if search:
            q=f"%{search}%"
            rows=c.execute("""
            SELECT * FROM products
            WHERE source_title LIKE ? OR ai_title LIKE ? OR shop_name LIKE ? OR source_url LIKE ?
            ORDER BY id DESC
            """,(q,q,q,q)).fetchall()
        else:
            rows=c.execute("SELECT * FROM products ORDER BY id DESC").fetchall()
    return [_row(r) for r in rows]

def get_product(pid:int):
    with conn() as c:
        return _row(c.execute("SELECT * FROM products WHERE id=?", (pid,)).fetchone())

def create_product(data:dict)->int:
    now=_now()
    p=_payload(data, now, now)
    with conn() as c:
        cur=c.execute("""
        INSERT INTO products(
          source_url,offer_id,source_title,shop_name,ai_title,description,ai_instruction,
          cost,sale_price,pricing_mode,pricing_value,stock,min_order,sku_json,attrs_json,
          images_json,image_types_json,posts_json,status,publish_state,last_error,created_at,updated_at
        ) VALUES(
          :source_url,:offer_id,:source_title,:shop_name,:ai_title,:description,:ai_instruction,
          :cost,:sale_price,:pricing_mode,:pricing_value,:stock,:min_order,:sku_json,:attrs_json,
          :images_json,:image_types_json,:posts_json,:status,:publish_state,:last_error,:created_at,:updated_at
        )""", p)
        return int(cur.lastrowid)

def _payload(data, created, updated):
    return {
        "source_url":data.get("source_url",""),
        "offer_id":data.get("offer_id",""),
        "source_title":data.get("source_title",data.get("title","")),
        "shop_name":data.get("shop_name",""),
        "ai_title":data.get("ai_title",""),
        "description":data.get("description",""),
        "ai_instruction":data.get("ai_instruction",""),
        "cost":float(data.get("cost",0) or 0),
        "sale_price":float(data.get("sale_price",0) or 0),
        "pricing_mode":data.get("pricing_mode","multiplier"),
        "pricing_value":float(data.get("pricing_value",1.6) or 1.6),
        "stock":str(data.get("stock","")),
        "min_order":str(data.get("min_order","")),
        "sku_json":json.dumps(data.get("sku",[]),ensure_ascii=False),
        "attrs_json":json.dumps(data.get("attrs",{}),ensure_ascii=False),
        "images_json":json.dumps(data.get("images",[]),ensure_ascii=False),
        "image_types_json":json.dumps(data.get("image_types",{}),ensure_ascii=False),
        "posts_json":json.dumps(data.get("posts",[]),ensure_ascii=False),
        "status":data.get("status","待处理"),
        "publish_state":data.get("publish_state",""),
        "last_error":data.get("last_error",""),
        "created_at":created,
        "updated_at":updated,
    }

def update_product(pid:int, data:dict):
    old=get_product(pid)
    if not old:return
    merged={**old,**data}
    p=_payload(merged, old["created_at"], _now())
    p["id"]=pid
    with conn() as c:
        c.execute("""
        UPDATE products SET
          source_url=:source_url,offer_id=:offer_id,source_title=:source_title,shop_name=:shop_name,
          ai_title=:ai_title,description=:description,ai_instruction=:ai_instruction,cost=:cost,
          sale_price=:sale_price,pricing_mode=:pricing_mode,pricing_value=:pricing_value,stock=:stock,
          min_order=:min_order,sku_json=:sku_json,attrs_json=:attrs_json,images_json=:images_json,
          image_types_json=:image_types_json,posts_json=:posts_json,status=:status,
          publish_state=:publish_state,last_error=:last_error,updated_at=:updated_at
        WHERE id=:id
        """,p)

def delete_products(ids:Iterable[int]):
    ids=[int(x) for x in ids]
    if not ids:return
    marks=",".join("?" for _ in ids)
    with conn() as c:c.execute(f"DELETE FROM products WHERE id IN ({marks})",ids)

def set_status(ids, status, publish_state=None, last_error=None):
    for pid in ids:
        payload={"status":status}
        if publish_state is not None: payload["publish_state"]=publish_state
        if last_error is not None: payload["last_error"]=last_error
        update_product(int(pid),payload)
