import sys
from PySide6.QtWidgets import QApplication
from core.db import init_db
from ui.main_window import MainWindow

def main():
    init_db()
    app=QApplication(sys.argv)
    app.setApplicationName("1688闲鱼助手V3")
    w=MainWindow();w.show()
    sys.exit(app.exec())

if __name__=="__main__":main()
